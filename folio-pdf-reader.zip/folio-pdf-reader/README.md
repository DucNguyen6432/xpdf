# Folio – a minimalist desktop PDF reader

Electron + PDF.js (v3.11.174).

## Run it
1. Install Node.js 18+ from https://nodejs.org
2. In this folder:
   ```
   npm install
   npm start
   ```
   Open a file with the **Open** button, Ctrl+O, drag & drop, or `npm start -- path/to/file.pdf`.

## Build an installer (optional)
```
npm run dist
```

## Shortcuts
| Key | Action |
|---|---|
| Ctrl+O | Open file |
| Ctrl+F | Find (Enter / Shift+Enter = next / previous) |
| Ctrl + `+` / `-` / `0` | Zoom in / out / automatic |
| Ctrl + mouse wheel | Zoom |
| N / J, P / K | Next / previous page |
| Esc | Close search bar, leave presentation mode |
