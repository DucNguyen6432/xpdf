'use strict';

const { pdfjsLib, pdfjsViewer } = window;
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];

pdfjsLib.GlobalWorkerOptions.workerSrc = '../node_modules/pdfjs-dist/build/pdf.worker.js';
const CMAP_URL = '../node_modules/pdfjs-dist/cmaps/';
const FONT_URL = '../node_modules/pdfjs-dist/standard_fonts/';

/* ───────────────────────── Icons ───────────────────────── */
const ICONS = {
  sidebar: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M9 4v16"/>',
  folder: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
  up: '<path d="m6 15 6-6 6 6"/>',
  down: '<path d="m6 9 6 6 6-6"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  minus: '<path d="M5 12h14"/>',
  close: '<path d="M6 6l12 12M18 6 6 18"/>',
  present: '<rect x="3" y="4" width="18" height="12" rx="2"/><path d="M12 16v4M8 20h8"/>',
  rotate: '<path d="M21 12a9 9 0 1 1-3-6.7"/><path d="M21 4v5h-5"/>',
  cursor: '<path d="M9 4h6M9 20h6M12 4v16"/>',
  hand: '<path d="M18 11V6a2 2 0 0 0-4 0v4M14 10V4a2 2 0 0 0-4 0v6M10 10.5V6a2 2 0 0 0-4 0v8"/><path d="M18 8a2 2 0 1 1 4 0v6a8 8 0 0 1-8 8h-2c-2.8 0-4.2-.8-5.7-2.4l-3.6-3.7a2 2 0 0 1 3-2.7L8 15"/>',
  vertical: '<path d="M12 3v18M8 7l4-4 4 4M8 17l4 4 4-4"/>',
  horizontal: '<path d="M3 12h18M7 8l-4 4 4 4M17 8l4 4-4 4"/>',
  wrapped: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
  spreadNone: '<rect x="7" y="3" width="10" height="18" rx="1.5"/>',
  spreadOdd: '<rect x="2" y="5" width="9.5" height="14" rx="1"/><rect x="12.5" y="5" width="9.5" height="14" rx="1"/><text x="6.75" y="15" font-size="7" text-anchor="middle" fill="currentColor" stroke="none">1</text><text x="17.25" y="15" font-size="7" text-anchor="middle" fill="currentColor" stroke="none">2</text>',
  spreadEven: '<rect x="2" y="5" width="9.5" height="14" rx="1"/><rect x="12.5" y="5" width="9.5" height="14" rx="1"/><text x="6.75" y="15" font-size="7" text-anchor="middle" fill="currentColor" stroke="none">2</text><text x="17.25" y="15" font-size="7" text-anchor="middle" fill="currentColor" stroke="none">3</text>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>',
  file: '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5M9 13h6M9 17h6"/>'
};
$$('[data-icon]').forEach((el) => {
  el.insertAdjacentHTML('afterbegin', `<svg viewBox="0 0 24 24" aria-hidden="true">${ICONS[el.dataset.icon]}</svg>`);
});

/* ───────────────────────── Viewer setup ───────────────────────── */
const container = $('#viewerContainer');
const eventBus = new pdfjsViewer.EventBus();
const linkService = new pdfjsViewer.PDFLinkService({ eventBus });
const findController = new pdfjsViewer.PDFFindController({ eventBus, linkService });
const pdfViewer = new pdfjsViewer.PDFViewer({
  container,
  viewer: $('#viewer'),
  eventBus,
  linkService,
  findController,
  textLayerMode: 1,
  removePageBorders: true
});
linkService.setViewer(pdfViewer);

const view = { scrollMode: 0, spreadMode: 0 };   // remembered between documents
let pdfDoc = null;
let loadingTask = null;
let docMeta = { name: '', size: 0 };

/* ───────────────────────── Elements ───────────────────────── */
const pageInput = $('#pageInput');
const pageTotal = $('#pageTotal');
const zoomSelect = $('#zoomSelect');
const sidebar = $('#sidebar');
const thumbsEl = $('#thumbs');

function setDocEnabled(on) {
  $$('[data-needs-doc]').forEach((el) => (el.disabled = !on));
  $('#empty').hidden = on;
}
setDocEnabled(false);

/* ───────────────────────── Opening files ───────────────────────── */
async function openWithDialog() {
  const file = await window.api.openFileDialog();
  if (file) await loadPdf(file.data, file.name);
}

async function closeDocument() {
  pdfViewer.setDocument(null);
  linkService.setDocument(null, null);
  thumbToken++;
  thumbsEl.innerHTML = '';
  if (loadingTask) { try { await loadingTask.destroy(); } catch (_) {} }
  loadingTask = null;
  pdfDoc = null;
}

function askPassword(wasWrong) {
  return new Promise((resolve) => {
    const dlg = $('#pwDialog');
    const input = $('#pwInput');
    $('#pwMsg').textContent = wasWrong
      ? 'That password is incorrect. Try again.'
      : 'This document is protected. Enter its password to open it.';
    input.value = '';
    const done = (v) => { dlg.close(); resolve(v); };
    $('#pwForm').onsubmit = (e) => { e.preventDefault(); done(input.value); };
    $('#pwCancel').onclick = () => done(null);
    dlg.oncancel = () => resolve(null);
    dlg.showModal();
    input.focus();
  });
}

async function loadPdf(data, name) {
  $('#loading').hidden = false;
  try {
    await closeDocument();
    const size = data.byteLength;           // read before PDF.js takes ownership of the buffer
    const task = pdfjsLib.getDocument({ data, cMapUrl: CMAP_URL, cMapPacked: true, standardFontDataUrl: FONT_URL });
    task.onPassword = async (update, reason) => {
      const pw = await askPassword(reason === pdfjsLib.PasswordResponses.INCORRECT_PASSWORD);
      if (pw === null) task.destroy(); else update(pw);
    };
    loadingTask = task;
    const pdf = await task.promise;

    pdfDoc = pdf;
    docMeta = { name, size };
    pdfViewer.setDocument(pdf);
    linkService.setDocument(pdf, null);
    pageTotal.textContent = `/ ${pdf.numPages}`;
    pageInput.value = '1';
    document.title = `${name} – Folio`;
    setDocEnabled(true);
    buildThumbnails(pdf);
  } catch (err) {
    if (err && err.name !== 'PasswordException' && !String(err.message).includes('destroyed')) {
      alert(`Could not open "${name}".\n\n${err.message || err}`);
    }
    if (!pdfDoc) { setDocEnabled(false); document.title = 'Folio'; }
  } finally {
    $('#loading').hidden = true;
  }
}

/* Drag & drop */
let dragDepth = 0;
window.addEventListener('dragenter', (e) => { e.preventDefault(); dragDepth++; $('#dropHint').hidden = false; });
window.addEventListener('dragleave', () => { if (--dragDepth <= 0) { dragDepth = 0; $('#dropHint').hidden = true; } });
window.addEventListener('dragover', (e) => e.preventDefault());
window.addEventListener('drop', async (e) => {
  e.preventDefault();
  dragDepth = 0; $('#dropHint').hidden = true;
  const f = [...(e.dataTransfer?.files || [])].find((x) => /\.pdf$/i.test(x.name) || x.type === 'application/pdf');
  if (f) await loadPdf(new Uint8Array(await f.arrayBuffer()), f.name);
});

$('#btnOpen').addEventListener('click', openWithDialog);
$('#btnOpenEmpty').addEventListener('click', openWithDialog);

/* ───────────────────────── Viewer events ───────────────────────── */
eventBus.on('pagesinit', () => {
  pdfViewer.pagesRotation = 0;
  pdfViewer.scrollMode = view.scrollMode;
  pdfViewer.spreadMode = view.spreadMode;
  pdfViewer.currentScaleValue = 'auto';
});

eventBus.on('pagechanging', (e) => {
  pageInput.value = e.pageNumber;
  setActiveThumb(e.pageNumber);
});

eventBus.on('scalechanging', (e) => {
  let value = e.presetValue;
  if (!value) {
    const match = [...zoomSelect.options].find((o) => o.value && !isNaN(o.value) && Math.abs(+o.value - e.scale) < 0.001);
    value = match && match.value;
  }
  if (value && [...zoomSelect.options].some((o) => o.value === value)) {
    zoomSelect.value = value;
  } else {
    const custom = zoomSelect.querySelector('[value="custom"]');
    custom.textContent = `${Math.round(e.scale * 100)}%`;
    custom.hidden = false;
    zoomSelect.value = 'custom';
  }
});

// Keep preset zoom modes (auto / fit / width) correct when the window or sidebar resizes.
let resizeTimer = null;
new ResizeObserver(() => {
  clearTimeout(resizeTimer);
  resizeTimer = setTimeout(() => {
    if (!pdfViewer.pagesCount) return;
    const v = pdfViewer.currentScaleValue;
    if (['auto', 'page-fit', 'page-width'].includes(v)) pdfViewer.currentScaleValue = v;
    else pdfViewer.update();
  }, 60);
}).observe($('#viewerWrap'));

/* ───────────────────────── Navigation ───────────────────────── */
const goPrev = () => { if (pdfViewer.currentPageNumber > 1) pdfViewer.currentPageNumber--; };
const goNext = () => { if (pdfViewer.currentPageNumber < pdfViewer.pagesCount) pdfViewer.currentPageNumber++; };
$('#btnPrev').addEventListener('click', goPrev);
$('#btnNext').addEventListener('click', goNext);

pageInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') pageInput.blur(); });
pageInput.addEventListener('focus', () => pageInput.select());
pageInput.addEventListener('change', () => {
  const n = parseInt(pageInput.value, 10);
  if (Number.isFinite(n)) pdfViewer.currentPageNumber = Math.min(Math.max(n, 1), pdfViewer.pagesCount);
  pageInput.value = pdfViewer.currentPageNumber;
});

/* ───────────────────────── Zoom ───────────────────────── */
const ZOOM_STEPS = [0.5, 0.75, 1, 1.25, 1.5, 2, 3, 4];
function zoomBy(dir) {
  if (!pdfViewer.pagesCount) return;
  const s = pdfViewer.currentScale;
  let next;
  if (dir > 0) next = ZOOM_STEPS.find((z) => z > s + 0.001) ?? ZOOM_STEPS.at(-1);
  else next = [...ZOOM_STEPS].reverse().find((z) => z < s - 0.001) ?? ZOOM_STEPS[0];
  pdfViewer.currentScaleValue = String(next);
}
$('#btnZoomIn').addEventListener('click', () => zoomBy(1));
$('#btnZoomOut').addEventListener('click', () => zoomBy(-1));
zoomSelect.addEventListener('change', () => {
  if (zoomSelect.value !== 'custom') pdfViewer.currentScaleValue = zoomSelect.value;
  zoomSelect.blur();
});

let wheelLock = false;
container.addEventListener('wheel', (e) => {
  if (!e.ctrlKey) return;
  e.preventDefault();
  if (wheelLock) return;
  wheelLock = true;
  setTimeout(() => (wheelLock = false), 90);
  zoomBy(e.deltaY < 0 ? 1 : -1);
}, { passive: false });

/* ───────────────────────── Tools: rotate, hand/select, scroll, spread ───────────────────────── */
$('#btnRotate').addEventListener('click', () => {
  pdfViewer.pagesRotation = (pdfViewer.pagesRotation + 90) % 360;
});

let tool = 'select';
function setTool(t) {
  tool = t;
  container.classList.toggle('hand-tool', t === 'hand');
  $('#toolSelect').classList.toggle('active', t === 'select');
  $('#toolHand').classList.toggle('active', t === 'hand');
}
$('#toolSelect').addEventListener('click', () => setTool('select'));
$('#toolHand').addEventListener('click', () => setTool('hand'));

let drag = null;
container.addEventListener('mousedown', (e) => {
  if (tool !== 'hand' || e.button !== 0) return;
  e.preventDefault();
  drag = { x: e.clientX, y: e.clientY, left: container.scrollLeft, top: container.scrollTop };
  container.classList.add('grabbing');
});
window.addEventListener('mousemove', (e) => {
  if (!drag) return;
  container.scrollLeft = drag.left - (e.clientX - drag.x);
  container.scrollTop = drag.top - (e.clientY - drag.y);
});
window.addEventListener('mouseup', () => { drag = null; container.classList.remove('grabbing'); });

function bindSegment(attr, apply) {
  const buttons = $$(`[data-${attr}]`);
  buttons.forEach((b) => b.addEventListener('click', () => {
    apply(+b.dataset[attr]);
    buttons.forEach((x) => x.classList.toggle('active', x === b));
  }));
}
bindSegment('scroll', (m) => { view.scrollMode = m; pdfViewer.scrollMode = m; });
bindSegment('spread', (m) => { view.spreadMode = m; pdfViewer.spreadMode = m; });

/* ───────────────────────── Sidebar & thumbnails ───────────────────────── */
$('#btnSidebar').addEventListener('click', () => {
  const collapsed = sidebar.classList.toggle('collapsed');
  $('#btnSidebar').classList.toggle('active', !collapsed);
});
$('#btnSidebar').classList.add('active');

const THUMB_W = 130;
let thumbToken = 0;
let thumbObserver = null;
let thumbQueue = [];
let thumbBusy = false;

async function buildThumbnails(pdf) {
  const token = ++thumbToken;
  thumbObserver?.disconnect();
  thumbQueue = [];
  thumbsEl.innerHTML = '';

  const first = await pdf.getPage(1);
  if (token !== thumbToken) return;
  const vp = first.getViewport({ scale: 1 });
  const height = Math.round((THUMB_W * vp.height) / vp.width);

  thumbObserver = new IntersectionObserver((entries) => {
    for (const en of entries) {
      if (en.isIntersecting) {
        thumbQueue.push(en.target);
        thumbObserver.unobserve(en.target);
      }
    }
    pumpThumbs(token);
  }, { root: thumbsEl, rootMargin: '500px 0px' });

  const frag = document.createDocumentFragment();
  for (let n = 1; n <= pdf.numPages; n++) {
    const b = document.createElement('button');
    b.className = 'thumb';
    b.dataset.page = n;
    b.title = `Page ${n}`;
    b.innerHTML = `<span class="thumb-frame" style="width:${THUMB_W}px;height:${height}px"><canvas></canvas></span><span class="thumb-label">${n}</span>`;
    b.addEventListener('click', () => { pdfViewer.currentPageNumber = n; });
    frag.appendChild(b);
  }
  thumbsEl.appendChild(frag);
  $$('.thumb', thumbsEl).forEach((el) => thumbObserver.observe(el));
  setActiveThumb(pdfViewer.currentPageNumber || 1);
}

async function pumpThumbs(token) {
  if (thumbBusy) return;
  thumbBusy = true;
  while (thumbQueue.length && token === thumbToken) {
    const el = thumbQueue.shift();
    if (!el.isConnected) continue;
    try {
      const page = await pdfDoc.getPage(+el.dataset.page);
      if (token !== thumbToken) break;
      const base = page.getViewport({ scale: 1 });
      const scale = THUMB_W / base.width;
      const dpr = window.devicePixelRatio || 1;
      const vp = page.getViewport({ scale: scale * dpr });
      const canvas = el.querySelector('canvas');
      canvas.width = Math.floor(vp.width);
      canvas.height = Math.floor(vp.height);
      canvas.style.width = `${vp.width / dpr}px`;
      canvas.style.height = `${vp.height / dpr}px`;
      el.querySelector('.thumb-frame').style.height = `${vp.height / dpr}px`;
      await page.render({ canvasContext: canvas.getContext('2d'), viewport: vp }).promise;
      el.classList.add('ready');
      page.cleanup();
    } catch (_) { /* thumbnail failures are non-fatal */ }
  }
  thumbBusy = false;
}

function setActiveThumb(n) {
  $$('.thumb.active', thumbsEl).forEach((t) => t.classList.remove('active'));
  const el = thumbsEl.querySelector(`.thumb[data-page="${n}"]`);
  if (!el) return;
  el.classList.add('active');
  el.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
}

/* ───────────────────────── Find ───────────────────────── */
const findBar = $('#findBar');
const findInput = $('#findInput');
const findStatus = $('#findStatus');
const opts = { highlight: $('#optHighlight'), cs: $('#optCase'), diac: $('#optDiacritics'), whole: $('#optWhole') };
const isOn = (b) => b.getAttribute('aria-pressed') === 'true';

function dispatchFind(type, previous = false) {
  eventBus.dispatch('find', {
    source: window,
    type,
    query: findInput.value,
    caseSensitive: isOn(opts.cs),
    entireWord: isOn(opts.whole),
    highlightAll: isOn(opts.highlight),
    findPrevious: previous,
    matchDiacritics: isOn(opts.diac)
  });
}

function openFind() {
  if (!pdfDoc) return;
  findBar.hidden = false;
  $('#btnSearch').classList.add('active');
  findInput.focus();
  findInput.select();
  if (findInput.value) dispatchFind('');
}
function closeFind() {
  findBar.hidden = true;
  $('#btnSearch').classList.remove('active');
  eventBus.dispatch('findbarclose', { source: window });
  findStatus.textContent = '';
  findInput.classList.remove('no-match');
}

function renderFindStatus(state, counts) {
  const FS = pdfjsViewer.FindState || { FOUND: 0, NOT_FOUND: 1, WRAPPED: 2, PENDING: 3 };
  findInput.classList.toggle('no-match', state === FS.NOT_FOUND);
  if (!findInput.value) { findStatus.textContent = ''; return; }
  if (state === FS.NOT_FOUND) { findStatus.textContent = 'Phrase not found'; return; }
  if (state === FS.PENDING && !(counts && counts.total)) { findStatus.textContent = 'Searching…'; return; }
  if (counts && counts.total > 0) {
    findStatus.textContent = `${counts.current.toLocaleString()} of ${counts.total.toLocaleString()} match${counts.total === 1 ? '' : 'es'}`;
  }
}
let lastFindState = 0;
eventBus.on('updatefindcontrolstate', (e) => { lastFindState = e.state; renderFindStatus(e.state, e.matchesCount); });
eventBus.on('updatefindmatchescount', (e) => renderFindStatus(lastFindState, e.matchesCount));

$('#btnSearch').addEventListener('click', () => (findBar.hidden ? openFind() : closeFind()));
$('#findClose').addEventListener('click', closeFind);
$('#findNext').addEventListener('click', () => dispatchFind('again', false));
$('#findPrev').addEventListener('click', () => dispatchFind('again', true));
findInput.addEventListener('input', () => dispatchFind(''));
findInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') { e.preventDefault(); dispatchFind('again', e.shiftKey); }
});
const optTypes = { highlight: 'highlightallchange', cs: 'casesensitivitychange', diac: 'diacriticmatchingchange', whole: 'entirewordchange' };
Object.entries(opts).forEach(([key, btn]) => btn.addEventListener('click', () => {
  btn.setAttribute('aria-pressed', String(!isOn(btn)));
  if (findInput.value) dispatchFind(optTypes[key]);
}));

/* ───────────────────────── Document properties ───────────────────────── */
function formatBytes(b) {
  const kb = b / 1024;
  const human = kb < 1024 ? `${kb.toFixed(kb < 10 ? 1 : 0)} KB` : `${(kb / 1024).toFixed(2)} MB`;
  return `${human} (${b.toLocaleString()} bytes)`;
}
function parsePdfDate(s) {
  const m = /^D:(\d{4})(\d{2})?(\d{2})?(\d{2})?(\d{2})?(\d{2})?(Z|[+-]\d{2}'?(?:\d{2}'?)?)?/.exec(s || '');
  if (!m) return '';
  const [, y, mo = '01', d = '01', h = '00', mi = '00', se = '00', tz] = m;
  let iso = `${y}-${mo}-${d}T${h}:${mi}:${se}`;
  if (tz === 'Z') iso += 'Z';
  else if (tz) { const t = tz.replace(/'/g, ''); iso += `${t.slice(0, 3)}:${t.slice(3, 5) || '00'}`; }
  const dt = new Date(iso);
  return isNaN(dt) ? '' : dt.toLocaleString(undefined, { dateStyle: 'long', timeStyle: 'medium' });
}
function describePageSize(w, h) {
  const mm = [w / 72 * 25.4, h / 72 * 25.4];
  const [a, b] = [Math.min(...mm), Math.max(...mm)];
  const known = { A3: [297, 420], A4: [210, 297], A5: [148, 210], Letter: [215.9, 279.4], Legal: [215.9, 355.6] };
  const name = Object.keys(known).find((k) => Math.abs(known[k][0] - a) < 2.5 && Math.abs(known[k][1] - b) < 2.5);
  const inch = (v) => (v / 72).toFixed(2);
  const orient = w > h ? 'Landscape' : 'Portrait';
  return `${inch(w)} × ${inch(h)} in (${mm[0].toFixed(0)} × ${mm[1].toFixed(0)} mm${name ? `, ${name}` : ''}, ${orient})`;
}

async function showProperties() {
  if (!pdfDoc) return;
  const { info = {} } = await pdfDoc.getMetadata().catch(() => ({ info: {} }));
  const page = await pdfDoc.getPage(1);
  const vp = page.getViewport({ scale: 1 });
  const v = {
    fileName: docMeta.name,
    fileSize: formatBytes(docMeta.size),
    title: info.Title, author: info.Author, subject: info.Subject, keywords: info.Keywords,
    created: parsePdfDate(info.CreationDate), modified: parsePdfDate(info.ModDate),
    creator: info.Creator, producer: info.Producer, version: info.PDFFormatVersion,
    pages: pdfDoc.numPages,
    pageSize: describePageSize(vp.width, vp.height),
    fastWeb: pdfDoc.isLinearized ? 'Yes' : 'No'
  };
  $$('#propsList [data-p]').forEach((dd) => { dd.textContent = v[dd.dataset.p] || '–'; });
  $('#propsDialog').showModal();
}
$('#btnProps').addEventListener('click', showProperties);
$('#propsClose').addEventListener('click', () => $('#propsDialog').close());
$('#propsDialog').addEventListener('click', (e) => { if (e.target === e.currentTarget) e.currentTarget.close(); });

/* ───────────────────────── Presentation mode ───────────────────────── */
let savedView = null;
$('#btnPresent').addEventListener('click', () => {
  if (pdfDoc) document.documentElement.requestFullscreen().catch(() => {});
});
document.addEventListener('fullscreenchange', () => {
  const on = !!document.fullscreenElement;
  document.body.classList.toggle('presentation', on);
  if (on) {
    savedView = { scroll: pdfViewer.scrollMode, spread: pdfViewer.spreadMode, scale: pdfViewer.currentScaleValue };
    pdfViewer.scrollMode = 3;   // single page at a time
    pdfViewer.spreadMode = 0;
    setTimeout(() => (pdfViewer.currentScaleValue = 'page-fit'), 150);
  } else if (savedView) {
    pdfViewer.scrollMode = savedView.scroll;
    pdfViewer.spreadMode = savedView.spread;
    setTimeout(() => { pdfViewer.currentScaleValue = savedView.scale; savedView = null; }, 150);
  }
});
container.addEventListener('click', () => { if (document.body.classList.contains('presentation')) goNext(); });
let slideLock = false;
container.addEventListener('wheel', (e) => {
  if (!document.body.classList.contains('presentation') || slideLock) return;
  slideLock = true; setTimeout(() => (slideLock = false), 350);
  e.deltaY > 0 ? goNext() : goPrev();
}, { passive: true });

/* ───────────────────────── Keyboard shortcuts ───────────────────────── */
window.addEventListener('keydown', (e) => {
  const mod = e.ctrlKey || e.metaKey;
  const k = e.key;

  if (mod && k.toLowerCase() === 'o') { e.preventDefault(); openWithDialog(); return; }
  if (mod && k.toLowerCase() === 'f') { e.preventDefault(); openFind(); return; }
  if (mod && (k === '=' || k === '+')) { e.preventDefault(); zoomBy(1); return; }
  if (mod && (k === '-' || k === '_')) { e.preventDefault(); zoomBy(-1); return; }
  if (mod && k === '0') { e.preventDefault(); if (pdfDoc) pdfViewer.currentScaleValue = 'auto'; return; }
  if (k === 'Escape' && !findBar.hidden) { closeFind(); return; }

  const tag = document.activeElement?.tagName;
  if (tag === 'INPUT' || tag === 'SELECT' || tag === 'TEXTAREA' || !pdfDoc) return;

  if (document.body.classList.contains('presentation')) {
    if (['ArrowRight', 'ArrowDown', 'PageDown', ' ', 'Enter'].includes(k)) { e.preventDefault(); goNext(); }
    else if (['ArrowLeft', 'ArrowUp', 'PageUp', 'Backspace'].includes(k)) { e.preventDefault(); goPrev(); }
    else if (k === 'Home') pdfViewer.currentPageNumber = 1;
    else if (k === 'End') pdfViewer.currentPageNumber = pdfViewer.pagesCount;
    return;
  }
  if (k === 'n' || k === 'j') goNext();
  else if (k === 'p' || k === 'k') goPrev();
  else if (k === 'Home' && !mod) pdfViewer.currentPageNumber = 1;
  else if (k === 'End' && !mod) pdfViewer.currentPageNumber = pdfViewer.pagesCount;
});

/* ───────────────────────── Startup ───────────────────────── */
window.api.getInitialFile().then((f) => { if (f) loadPdf(f.data, f.name); });
