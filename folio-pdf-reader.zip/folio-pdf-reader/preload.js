'use strict';
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('api', {
  openFileDialog: () => ipcRenderer.invoke('dialog:open'),
  getInitialFile: () => ipcRenderer.invoke('app:initial-file')
});
