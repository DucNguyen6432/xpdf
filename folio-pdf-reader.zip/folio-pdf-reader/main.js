'use strict';
const { app, BrowserWindow, ipcMain, dialog, Menu } = require('electron');
const fs = require('fs');
const path = require('path');

let win = null;

// A PDF path passed on the command line ("Open with…" or `npm start -- file.pdf`)
function findInitialPdf() {
  const args = process.argv.slice(app.isPackaged ? 1 : 2);
  return args.find((a) => a.toLowerCase().endsWith('.pdf') && fs.existsSync(a)) || null;
}

async function readPdf(filePath) {
  const buf = await fs.promises.readFile(filePath);
  return { name: path.basename(filePath), size: buf.length, data: new Uint8Array(buf) };
}

function createWindow() {
  win = new BrowserWindow({
    width: 1320,
    height: 880,
    minWidth: 1100,
    minHeight: 600,
    backgroundColor: '#18181b',
    title: 'Folio',
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false
    }
  });
  win.loadFile(path.join(__dirname, 'src', 'index.html'));
  win.on('closed', () => (win = null));
}

ipcMain.handle('dialog:open', async () => {
  const res = await dialog.showOpenDialog(win, {
    title: 'Open PDF',
    properties: ['openFile'],
    filters: [{ name: 'PDF documents', extensions: ['pdf'] }]
  });
  if (res.canceled || !res.filePaths.length) return null;
  return readPdf(res.filePaths[0]);
});

ipcMain.handle('app:initial-file', async () => {
  const p = findInitialPdf();
  return p ? readPdf(p) : null;
});

app.whenReady().then(() => {
  Menu.setApplicationMenu(null);
  createWindow();
  app.on('activate', () => BrowserWindow.getAllWindows().length === 0 && createWindow());
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
