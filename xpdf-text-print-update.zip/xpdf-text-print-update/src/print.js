'use strict';
/* Print dialog: printer, range, scaling / tiling / multi-page / booklet, duplex,
   live preview. Pages are rasterised (with any added text) and sent to the printer. */
(function () {
  const F = window.Folio;
  const LAYOUT = window.FolioLayout;
  const el = (id) => document.getElementById(id);
  const dlg = el('printDialog');
  const PRINT_DPI = 250;                 // raise for sharper (but larger) print jobs

  let mode = 'scale';
  let layout = null;
  let sheetIdx = 0;
  let token = 0;
  let printing = false;
  let printersLoaded = false;
  let timer = null;
  const previewCache = new Map();

  const store = {
    get(k, d) { try { const v = localStorage.getItem('xpdf.' + k); return v == null ? d : v; } catch (_) { return d; } },
    set(k, v) { try { localStorage.setItem('xpdf.' + k, v); } catch (_) {} }
  };
  const radio = (name) => (document.querySelector(`input[name="${name}"]:checked`) || {}).value;
  const num = (id, d, min, max) => Math.min(max, Math.max(min, parseFloat(el(id).value) || d));

  function readSettings() {
    return {
      printer: el('pPrinter').value,
      paper: el('pPaper').value,
      copies: Math.round(num('pCopies', 1, 1, 999)),
      collate: el('pCollate').checked,
      gray: el('pGray').checked,
      range: radio('prange'),
      pages: el('pPages').value,
      subset: el('pSubset').value,
      reverse: el('pReverse').checked,
      mode,
      scale: radio('pscale'),
      scalePct: num('pScalePct', 100, 1, 1000),
      tilePct: num('pTilePct', 100, 10, 1000),
      tileOverlap: num('pTileOverlap', 0.005, 0, 3),
      perSheet: +el('pPerSheet').value,
      order: el('pOrder').value,
      border: el('pBorder').checked,
      duplex: el('pDuplex').checked,
      flip: radio('pflip'),
      autoRotate: el('pAutoRotate').checked,
      autoCenter: el('pAutoCenter').checked,
      orient: el('pOrient').value,
      what: el('pWhat').value
    };
  }

  /* ───────── pages & layout ───────── */
  function visiblePages(tab) {
    try { return tab.pdfViewer._getVisiblePages().views.map((v) => v.id).sort((a, b) => a - b); }
    catch (_) { return [tab.page]; }
  }

  async function ensureSizes(tab, pages) {
    for (const p of pages) {
      if (tab.pageSizes[p]) continue;
      const pg = await tab.pdf.getPage(p);
      const vp = pg.getViewport({ scale: 1 });
      tab.pageSizes[p] = [vp.width, vp.height];
      pg.cleanup();
    }
  }

  async function computeLayout() {
    const tab = F.active;
    const s = readSettings();
    const pages = LAYOUT.choosePages(s, tab.pdf.numPages, tab.page, visiblePages(tab));
    await ensureSizes(tab, pages);
    return { s, tab, pages, ...LAYOUT.planSheets(s, pages, tab.pageSizes) };
  }

  async function renderPageCanvas(tab, pageNum, widthPx, markups) {
    const page = await tab.pdf.getPage(pageNum);
    const base = page.getViewport({ scale: 1 });
    const scale = Math.min(widthPx / base.width, 6000 / Math.max(base.width, base.height));
    const vp = page.getViewport({ scale });
    const canvas = document.createElement('canvas');
    canvas.width = Math.ceil(vp.width);
    canvas.height = Math.ceil(vp.height);
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#fff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    await page.render({
      canvasContext: ctx, viewport: vp, intent: 'print',
      annotationMode: F.pdfjsLib.AnnotationMode.ENABLE
    }).promise;
    if (markups && F.drawMarkups) F.drawMarkups(tab, pageNum, ctx, vp);
    page.cleanup();
    return canvas;
  }

  async function previewImage(L, page) {
    const markups = L.s.what === 'markups';
    const key = `${L.tab.id}|${page}|${markups}`;
    if (!previewCache.has(key)) {
      const c = await renderPageCanvas(L.tab, page, 900, markups);
      previewCache.set(key, c.toDataURL('image/jpeg', 0.8));
      c.width = c.height = 0;
    }
    return previewCache.get(key);
  }

  /* ───────── preview ───────── */
  function schedulePreview() { clearTimeout(timer); timer = setTimeout(updatePreview, 80); }

  async function updatePreview() {
    if (!dlg.open || !F.active || !F.active.pdf) return;
    const my = ++token;
    const stage = el('prevStage');
    let L;
    try { L = await computeLayout(); } catch (e) { return; }
    if (my !== token) return;
    layout = L;
    const n = L.sheets.length;
    sheetIdx = Math.min(sheetIdx, Math.max(0, n - 1));
    const slider = el('prevSlider');
    slider.max = Math.max(1, n); slider.value = sheetIdx + 1; slider.disabled = n < 2;
    el('prevPrev').disabled = sheetIdx <= 0;
    el('prevNext').disabled = sheetIdx >= n - 1;
    el('prevLabel').textContent = n ? `Page ${sheetIdx + 1} of ${n}` : 'No pages';
    el('pGo').disabled = !n || !el('pPrinter').value || printing;

    if (!n) {
      stage.innerHTML = '<div class="prev-empty">No pages selected.<br>Check the page range.</div>';
      el('prevInfo').textContent = '';
      return;
    }
    const sheet = L.sheets[sheetIdx];
    const pgs = [...new Set(sheet.placements.map((p) => p.page))];
    let imgs;
    try { imgs = await Promise.all(pgs.map((p) => previewImage(L, p))); } catch (e) { return; }
    if (my !== token) return;

    const k = Math.max(20, Math.min((stage.clientWidth - 28) / L.W, (stage.clientHeight - 28) / L.H));
    const css = pgs.map((p, i) => `.pg${p}{background-image:url("${imgs[i]}")}`).join('');
    stage.innerHTML = `<style>${css}</style>` +
      LAYOUT.sheetMarkup(sheet, L.W, L.H, (v) => `${(v * k).toFixed(2)}px`, { gray: L.s.gray });
    const first = L.tab.pageSizes[L.pages[0]];
    el('prevInfo').innerHTML =
      `<span>Zoom: ${(k / 96 * 100).toFixed(1)}%</span>` +
      `<span>Document: ${(first[0] / 72).toFixed(1)} × ${(first[1] / 72).toFixed(1)} in</span>` +
      `<span>Paper: ${L.W.toFixed(1)} × ${L.H.toFixed(1)} in</span>`;
  }

  /* ───────── dialog state ───────── */
  function updateEnabled() {
    const s = readSettings();
    el('pPages').disabled = s.range !== 'custom';
    el('pScalePct').disabled = s.scale !== 'custom';
    const booklet = mode === 'booklet';
    if (booklet) { el('pDuplex').checked = true; document.querySelector('input[name="pflip"][value="short"]').checked = true; }
    el('pDuplex').disabled = booklet;
    $$('input[name="pflip"]').forEach((r) => (r.disabled = booklet || !el('pDuplex').checked));
    el('pOrient').disabled = booklet;
    $$('.modes button').forEach((b) => b.classList.toggle('active', b.dataset.mode === mode));
    ['scale', 'tile', 'multi', 'booklet'].forEach((m) => (el('mode-' + m).hidden = m !== mode));
  }
  const $$ = (s) => [...dlg.querySelectorAll(s)];

  async function loadPrinters() {
    if (printersLoaded) return;
    const sel = el('pPrinter');
    let list = [];
    try { list = await window.api.getPrinters(); } catch (_) {}
    sel.innerHTML = '';
    if (!list.length) {
      const o = document.createElement('option'); o.value = ''; o.textContent = 'No printers found'; sel.appendChild(o);
    } else {
      for (const p of list) {
        const o = document.createElement('option');
        o.value = p.name; o.textContent = p.displayName + (p.isDefault ? ' (default)' : '');
        sel.appendChild(o);
      }
      const remembered = store.get('printer', '');
      const pick = list.find((p) => p.name === remembered) || list.find((p) => p.isDefault) || list[0];
      sel.value = pick.name;
    }
    printersLoaded = true;
  }

  async function openPrint() {
    const tab = F.active;
    if (!tab || !tab.pdf || dlg.open) return;
    previewCache.clear();
    sheetIdx = 0;
    el('pTotal').textContent = `/ ${tab.pdf.numPages}`;
    el('pPaper').value = store.get('paper', 'Letter');
    dlg.showModal();
    updateEnabled();
    await loadPrinters();
    schedulePreview();
  }

  async function doPrint() {
    if (printing) return;
    let L;
    try { L = await computeLayout(); } catch (e) { return; }
    if (!L.sheets.length) return;
    const s = L.s;
    printing = true;
    const btn = el('pGo');
    btn.disabled = true;
    try {
      const need = new Map();           // page -> widest rendering needed (inches)
      for (const sh of L.sheets) for (const p of sh.placements) need.set(p.page, Math.max(need.get(p.page) || 0, p.iw));
      const images = {};
      let i = 0;
      for (const [page, wIn] of need) {
        btn.textContent = `Preparing ${++i} / ${need.size}…`;
        const px = Math.round(Math.min(6000, Math.max(600, wIn * PRINT_DPI)));
        const canvas = await renderPageCanvas(L.tab, page, px, s.what === 'markups');
        images[page] = canvas.toDataURL('image/jpeg', 0.92);
        canvas.width = canvas.height = 0;
      }
      btn.textContent = 'Sending…';
      const html = LAYOUT.buildPrintHtml(L.sheets, L.W, L.H, images, s.gray);
      const duplexMode = s.duplex ? (s.flip === 'short' ? 'shortEdge' : 'longEdge') : 'simplex';
      const res = await window.api.printHtml({
        html, deviceName: s.printer, copies: s.copies, collate: s.collate,
        color: !s.gray, duplexMode, landscape: L.landscape, pageSize: s.paper
      });
      if (res && res.success) { dlg.close(); F.toast('Sent to the printer.'); }
      else alert(`Printing failed: ${(res && res.reason) || 'unknown error'}`);
    } catch (e) {
      alert(`Could not prepare the print job.\n\n${(e && e.message) || e}`);
    } finally {
      printing = false;
      btn.textContent = 'Print';
      btn.disabled = false;
    }
  }

  /* ───────── events ───────── */
  const onChange = () => {
    updateEnabled();
    store.set('printer', el('pPrinter').value);
    store.set('paper', el('pPaper').value);
    if (radio('prange') === 'custom' && document.activeElement && document.activeElement.name === 'prange') el('pPages').focus();
    schedulePreview();
  };
  dlg.addEventListener('input', onChange);
  dlg.addEventListener('change', onChange);
  $$('.modes button').forEach((b) => b.addEventListener('click', () => { mode = b.dataset.mode; sheetIdx = 0; onChange(); }));
  el('prevPrev').addEventListener('click', () => { sheetIdx = Math.max(0, sheetIdx - 1); updatePreview(); });
  el('prevNext').addEventListener('click', () => { sheetIdx += 1; updatePreview(); });
  el('prevSlider').addEventListener('input', (e) => { e.stopPropagation(); sheetIdx = +e.target.value - 1; updatePreview(); });
  el('pGo').addEventListener('click', doPrint);
  el('pCancel').addEventListener('click', () => dlg.close());
  el('printClose').addEventListener('click', () => dlg.close());
  el('btnPrint').addEventListener('click', openPrint);
  window.addEventListener('resize', () => { if (dlg.open) schedulePreview(); });
  window.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'p') { e.preventDefault(); openPrint(); }
  });
})();
