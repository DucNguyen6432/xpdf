/* Pure print-layout engine (no DOM). Used by the print dialog for both the
   live preview and the real print job, so what you see is what prints. */
(function (root) {
  'use strict';

  const PAPERS = {            // inches, portrait
    Letter: [8.5, 11], Legal: [8.5, 14], Tabloid: [11, 17],
    A3: [11.69, 16.54], A4: [8.27, 11.69], A5: [5.83, 8.27]
  };
  const MARGIN = 0.25;        // printable-area margin (inches) on every side
  const GAP = 0.12;           // gap between pages on a multi-page sheet

  function parseRange(text, max) {
    const out = [], seen = new Set();
    for (const part of String(text || '').split(',')) {
      const m = /^\s*(\d+)\s*(?:-\s*(\d+))?\s*$/.exec(part);
      if (!m) continue;
      let a = +m[1], b = m[2] ? +m[2] : a;
      if (a > b) [a, b] = [b, a];
      for (let p = Math.max(1, a); p <= Math.min(max, b); p++) {
        if (!seen.has(p)) { seen.add(p); out.push(p); }
      }
    }
    return out;
  }

  function choosePages(s, numPages, currentPage, visible) {
    let list;
    if (s.range === 'all') list = Array.from({ length: numPages }, (_, i) => i + 1);
    else if (s.range === 'page') list = [currentPage];
    else if (s.range === 'view') list = visible && visible.length ? visible.slice() : [currentPage];
    else list = parseRange(s.pages, numPages);
    if (s.subset === 'odd') list = list.filter((p) => p % 2 === 1);
    else if (s.subset === 'even') list = list.filter((p) => p % 2 === 0);
    if (s.reverse) list.reverse();
    return list;
  }

  function gridFor(n, landscape) {
    switch (n) {
      case 2: return landscape ? [2, 1] : [1, 2];
      case 4: return [2, 2];
      case 6: return landscape ? [3, 2] : [2, 3];
      case 9: return [3, 3];
      case 16: return [4, 4];
      default: return [1, 1];
    }
  }

  function gridCells(area, cols, rows, order) {
    const cw = (area.w - GAP * (cols - 1)) / cols;
    const ch = (area.h - GAP * (rows - 1)) / rows;
    const cells = [];
    for (let i = 0; i < cols * rows; i++) {
      const r = order === 'v' ? i % rows : Math.floor(i / cols);
      const c = order === 'v' ? Math.floor(i / rows) : i % cols;
      cells.push({ x: area.x + c * (cw + GAP), y: area.y + r * (ch + GAP), w: cw, h: ch });
    }
    return cells;
  }

  /* Position one page inside a cell. All numbers in inches.
     iw/ih = size of the page image (before rotation), cx/cy = its centre. */
  function placePage(page, sz, cell, scaleMode, s, border) {
    const w = sz[0] / 72, h = sz[1] / 72;
    const fit = (a, b) => Math.min(cell.w / a, cell.h / b);
    let scale = 1, rot = 0;

    if (scaleMode === 'fit') {
      scale = fit(w, h);
      const r = fit(h, w);
      if (s.autoRotate && r > scale * 1.0001) { rot = 90; scale = r; }
    } else if (scaleMode === 'reduce') {
      const n = fit(w, h);
      if (n >= 1) scale = 1;
      else {
        let sc = n;
        const r = fit(h, w);
        if (s.autoRotate && r > n) { rot = 90; sc = r; }
        scale = Math.min(1, sc);
      }
    } else {
      scale = scaleMode === 'custom' ? s.scalePct / 100 : 1;
      if (s.autoRotate && fit(h, w) > fit(w, h)) rot = 90;
    }

    const iw = w * scale, ih = h * scale;
    const vw = rot ? ih : iw, vh = rot ? iw : ih;
    let cx = cell.x + cell.w / 2, cy = cell.y + cell.h / 2;
    if (!s.autoCenter) { cx = cell.x + vw / 2; cy = cell.y + vh / 2; }
    const p = { page, clip: cell, cx, cy, iw, ih, rot };
    if (border) p.border = { x: cx - vw / 2, y: cy - vh / 2, w: vw, h: vh };
    return p;
  }

  function planSheets(s, pages, sizes) {
    const [pw, ph] = PAPERS[s.paper] || PAPERS.Letter;
    if (!pages.length) return { sheets: [], W: pw, H: ph, landscape: false };

    const first = sizes[pages[0]];
    const landscape = s.mode === 'booklet' ? true
      : s.orient === 'landscape' ? true
      : s.orient === 'portrait' ? false
      : first[0] > first[1];
    const W = landscape ? ph : pw, H = landscape ? pw : ph;
    const area = { x: MARGIN, y: MARGIN, w: W - 2 * MARGIN, h: H - 2 * MARGIN };
    const sheets = [];

    if (s.mode === 'tile') {
      const ov = Math.max(0, Math.min(s.tileOverlap || 0, Math.min(area.w, area.h) / 2));
      for (const pg of pages) {
        const PW = (sizes[pg][0] / 72) * (s.tilePct / 100);
        const PH = (sizes[pg][1] / 72) * (s.tilePct / 100);
        const cols = PW <= area.w + 1e-6 ? 1 : Math.ceil((PW - ov) / (area.w - ov));
        const rows = PH <= area.h + 1e-6 ? 1 : Math.ceil((PH - ov) / (area.h - ov));
        for (let r = 0; r < rows; r++) {
          for (let c = 0; c < cols; c++) {
            const left = area.x - c * (area.w - ov);
            const top = area.y - r * (area.h - ov);
            sheets.push({ placements: [{ page: pg, clip: area, cx: left + PW / 2, cy: top + PH / 2, iw: PW, ih: PH, rot: 0 }] });
          }
        }
      }
    } else if (s.mode === 'multi') {
      const [cols, rows] = gridFor(s.perSheet, landscape);
      const cells = gridCells(area, cols, rows, s.order === 'v' ? 'v' : 'h');
      for (let i = 0; i < pages.length; i += cells.length) {
        const chunk = pages.slice(i, i + cells.length);
        sheets.push({ placements: chunk.map((pg, k) => placePage(pg, sizes[pg], cells[k], 'fit', s, s.border)) });
      }
    } else if (s.mode === 'booklet') {
      const list = pages.slice();
      while (list.length % 4) list.push(null);
      const N = list.length;
      const cells = gridCells(area, 2, 1, 'h');
      for (let k = 0; k < N / 4; k++) {
        const front = [list[N - 2 * k - 1], list[2 * k]];
        const back = [list[2 * k + 1], list[N - 2 * k - 2]];
        for (const pair of [front, back]) {
          sheets.push({
            placements: pair.map((pg, i) => (pg ? placePage(pg, sizes[pg], cells[i], 'fit', s, s.border) : null)).filter(Boolean)
          });
        }
      }
    } else {
      for (const pg of pages) sheets.push({ placements: [placePage(pg, sizes[pg], area, s.scale, s, false)] });
    }
    return { sheets, W, H, landscape };
  }

  /* One sheet as HTML. `u` converts inches to a CSS length. */
  function sheetMarkup(sheet, W, H, u, opts) {
    opts = opts || {};
    let h = `<div class="sheet" style="width:${u(W)};height:${u(H - (opts.trim || 0))}">`;
    for (const p of sheet.placements) {
      const c = p.clip;
      const left = p.cx - p.iw / 2 - c.x, top = p.cy - p.ih / 2 - c.y;
      const style = `left:${u(left)};top:${u(top)};width:${u(p.iw)};height:${u(p.ih)};` +
        (p.rot ? 'transform:rotate(90deg);' : '') + (opts.gray ? 'filter:grayscale(1);' : '');
      h += `<div class="clip" style="left:${u(c.x)};top:${u(c.y)};width:${u(c.w)};height:${u(c.h)}">` +
           `<div class="pg pg${p.page}" style="${style}"></div></div>`;
      if (p.border) {
        h += `<div class="pborder" style="left:${u(p.border.x)};top:${u(p.border.y)};width:${u(p.border.w)};height:${u(p.border.h)}"></div>`;
      }
    }
    return h + '</div>';
  }

  const SHEET_CSS = '.sheet{position:relative;background:#fff;overflow:hidden}' +
    '.clip{position:absolute;overflow:hidden}' +
    '.pg{position:absolute;background-size:100% 100%;background-repeat:no-repeat}' +
    '.pborder{position:absolute;border:1px solid #000;box-sizing:border-box}';

  function buildPrintHtml(sheets, W, H, images, gray) {
    const css = Object.keys(images).map((p) => `.pg${p}{background-image:url("${images[p]}")}`).join('\n');
    const u = (n) => `${+n.toFixed(4)}in`;
    const body = sheets.map((s) => sheetMarkup(s, W, H, u, { gray, trim: 0.02 })).join('');
    return `<!doctype html><html><head><meta charset="utf-8"><style>
@page{margin:0}
html,body{margin:0;padding:0;background:#fff;-webkit-print-color-adjust:exact;print-color-adjust:exact}
${SHEET_CSS}
.sheet{break-after:page;page-break-after:always}
.sheet:last-child{break-after:auto;page-break-after:auto}
${css}
</style></head><body>${body}</body></html>`;
  }

  const api = { PAPERS, MARGIN, GAP, parseRange, choosePages, planSheets, sheetMarkup, buildPrintHtml, SHEET_CSS };
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.FolioLayout = api;
})(typeof window !== 'undefined' ? window : globalThis);
