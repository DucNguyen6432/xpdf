'use strict';

const { pdfjsLib, pdfjsViewer } = window;
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];

pdfjsLib.GlobalWorkerOptions.workerSrc = '../node_modules/pdfjs-dist/build/pdf.worker.js';
const CMAP_URL = '../node_modules/pdfjs-dist/cmaps/';
const FONT_URL = '../node_modules/pdfjs-dist/standard_fonts/';

/* ───────────────────────── Icons ───────────────────────── */
const ICONS = {
  sidebar: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M9 4v16"/>',
  folder: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
  up: '<path d="m6 15 6-6 6 6"/>',
  down: '<path d="m6 9 6 6 6-6"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  minus: '<path d="M5 12h14"/>',
  close: '<path d="M6 6l12 12M18 6 6 18"/>',
  present: '<rect x="3" y="4" width="18" height="12" rx="2"/><path d="M12 16v4M8 20h8"/>',
  rotate: '<path d="M21 12a9 9 0 1 1-3-6.7"/><path d="M21 4v5h-5"/>',
  cursor: '<path d="M9 4h6M9 20h6M12 4v16"/>',
  hand: '<path d="M18 11V6a2 2 0 0 0-4 0v4M14 10V4a2 2 0 0 0-4 0v6M10 10.5V6a2 2 0 0 0-4 0v8"/><path d="M18 8a2 2 0 1 1 4 0v6a8 8 0 0 1-8 8h-2c-2.8 0-4.2-.8-5.7-2.4l-3.6-3.7a2 2 0 0 1 3-2.7L8 15"/>',
  vertical: '<path d="M12 3v18M8 7l4-4 4 4M8 17l4 4 4-4"/>',
  horizontal: '<path d="M3 12h18M7 8l-4 4 4 4M17 8l4 4-4 4"/>',
  wrapped: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
  spreadNone: '<rect x="7" y="3" width="10" height="18" rx="1.5"/>',
  spreadOdd: '<rect x="2" y="5" width="9.5" height="14" rx="1"/><rect x="12.5" y="5" width="9.5" height="14" rx="1"/><text x="6.75" y="15" font-size="7" text-anchor="middle" fill="currentColor" stroke="none">1</text><text x="17.25" y="15" font-size="7" text-anchor="middle" fill="currentColor" stroke="none">2</text>',
  spreadEven: '<rect x="2" y="5" width="9.5" height="14" rx="1"/><rect x="12.5" y="5" width="9.5" height="14" rx="1"/><text x="6.75" y="15" font-size="7" text-anchor="middle" fill="currentColor" stroke="none">2</text><text x="17.25" y="15" font-size="7" text-anchor="middle" fill="currentColor" stroke="none">3</text>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>',
  file: '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5M9 13h6M9 17h6"/>'
};
Object.assign(ICONS, {
  text: '<path d="M5 6V4h14v2M12 4v16M9 20h6"/>',
  save: '<path d="M5 4h11l3 3v13H5z"/><path d="M8 4v5h7V4M8 20v-6h8v6"/>',
  print: '<path d="M7 9V3h10v6"/><rect x="4" y="9" width="16" height="8" rx="2"/><path d="M7 14h10v7H7z"/>',
  trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 12a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-12M9 7V4h6v3"/>'
});
const svg = (k) => `<svg viewBox="0 0 24 24" aria-hidden="true">${ICONS[k]}</svg>`;
$$('[data-icon]').forEach((el) => el.insertAdjacentHTML('afterbegin', svg(el.dataset.icon)));

/* ───────────────────────── Elements & global state ───────────────────────── */
const pageInput = $('#pageInput');
const pageTotal = $('#pageTotal');
const zoomSelect = $('#zoomSelect');
const sidebar = $('#sidebar');
const tabStrip = $('#tabs');
const findBar = $('#findBar');
const findInput = $('#findInput');
const findStatus = $('#findStatus');
const isPresenting = () => document.body.classList.contains('presentation');

const tabs = [];          // all open documents, in tab order
let active = null;        // the currently visible tab
let tabSeq = 0;
let tool = 'select';      // 'select' | 'hand' (shared by all tabs)

const APP_NAME = 'x PDF Reader';            // shown in the window title
const listeners = {};
const emit = (name, ...args) => (listeners[name] || []).forEach((fn) => { try { fn(...args); } catch (e) { console.error(e); } });
let toastTimer = null;
function toast(msg) {
  const t = $('#toast');
  t.textContent = msg; t.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (t.hidden = true), 3800);
}
// Small API used by text.js and print.js
window.Folio = {
  $, $$, svg, tabs, pdfjsLib, pdfjsViewer, toast,
  on: (name, fn) => (listeners[name] = listeners[name] || []).push(fn),
  busy: (on) => { $('#loading').hidden = !on; },
  get active() { return active; },
  get tool() { return tool; }
};

/* ───────────────────────── Tabs ───────────────────────── */
function createTab(name, size) {
  const container = document.createElement('div');
  container.className = 'viewer-container' + (tool === 'hand' ? ' hand-tool' : '') + (tool === 'text' ? ' text-tool' : '');
  container.tabIndex = 0;
  const viewerEl = document.createElement('div');
  viewerEl.className = 'pdfViewer';
  container.appendChild(viewerEl);
  $('#viewerWrap').insertBefore(container, $('#empty'));

  const thumbs = document.createElement('div');
  thumbs.className = 'thumbs';
  sidebar.appendChild(thumbs);

  // Every tab gets its own complete PDF.js viewer, so zoom, page, rotation,
  // scroll mode and search state are all kept independently per document.
  const eventBus = new pdfjsViewer.EventBus();
  const linkService = new pdfjsViewer.PDFLinkService({ eventBus });
  const findController = new pdfjsViewer.PDFFindController({ eventBus, linkService });
  const pdfViewer = new pdfjsViewer.PDFViewer({
    container, viewer: viewerEl, eventBus, linkService, findController,
    textLayerMode: 1, removePageBorders: true
  });
  linkService.setViewer(pdfViewer);

  const tab = {
    id: ++tabSeq, name, size, pdf: null, task: null, loading: true, closed: false, cancelled: false,
    container, thumbs, eventBus, linkService, findController, pdfViewer,
    view: { scrollMode: 0, spreadMode: 0 }, page: 1, lastScale: null,
    find: { state: 0, counts: null },
    thumb: { token: 0, observer: null, queue: [], busy: false },
    tabEl: null,
    annots: [], selectedId: null, saved: '[]', dirty: false, pageSizes: {}
  };
  wireTab(tab);
  buildTabEl(tab);
  tabs.push(tab);
  emit('tabcreated', tab);
  return tab;
}

function wireTab(tab) {
  const { eventBus, pdfViewer, container } = tab;

  eventBus.on('pagesinit', () => {
    pdfViewer.pagesRotation = 0;
    pdfViewer.scrollMode = tab.view.scrollMode;
    pdfViewer.spreadMode = tab.view.spreadMode;
    pdfViewer.currentScaleValue = 'auto';
  });
  eventBus.on('pagechanging', (e) => {
    tab.page = e.pageNumber;
    if (tab === active) { pageInput.value = e.pageNumber; setActiveThumb(tab, e.pageNumber); }
  });
  eventBus.on('scalechanging', (e) => {
    tab.lastScale = e;
    if (tab === active) updateZoomUI(e);
    emit('viewchanged', tab);
  });
  eventBus.on('rotationchanging', () => emit('viewchanged', tab));
  eventBus.on('pagerendered', (e) => emit('pagerendered', tab, e.pageNumber));
  eventBus.on('updatefindcontrolstate', (e) => {
    tab.find.state = e.state; tab.find.counts = e.matchesCount;
    if (tab === active) renderFindStatus(tab);
  });
  eventBus.on('updatefindmatchescount', (e) => {
    tab.find.counts = e.matchesCount;
    if (tab === active) renderFindStatus(tab);
  });

  // Hand tool: drag to pan
  container.addEventListener('mousedown', (e) => {
    if (tool !== 'hand' || e.button !== 0) return;
    e.preventDefault();
    drag = { c: container, x: e.clientX, y: e.clientY, left: container.scrollLeft, top: container.scrollTop };
    container.classList.add('grabbing');
  });
  // Ctrl + wheel zoom
  container.addEventListener('wheel', (e) => {
    if (!e.ctrlKey) return;
    e.preventDefault();
    if (wheelLock) return;
    wheelLock = true; setTimeout(() => (wheelLock = false), 90);
    zoomBy(e.deltaY < 0 ? 1 : -1);
  }, { passive: false });
  // Presentation mode: click / wheel change slide
  container.addEventListener('click', () => { if (isPresenting()) goNext(); });
  container.addEventListener('wheel', (e) => {
    if (!isPresenting() || slideLock) return;
    slideLock = true; setTimeout(() => (slideLock = false), 350);
    e.deltaY > 0 ? goNext() : goPrev();
  }, { passive: true });
}

function buildTabEl(tab) {
  const el = document.createElement('div');
  el.className = 'tab';
  el.setAttribute('role', 'tab');
  el.tabIndex = 0;
  el.title = tab.name;
  el.draggable = true;
  el.innerHTML = `<span class="tab-title"></span><button class="tab-close" tabindex="-1" title="Close tab (Ctrl+W)" aria-label="Close tab">${svg('close')}</button>`;
  $('.tab-title', el).textContent = tab.name;

  el.addEventListener('click', (e) => (e.target.closest('.tab-close') ? closeTab(tab) : activateTab(tab)));
  el.addEventListener('mousedown', (e) => { if (e.button === 1) e.preventDefault(); });
  el.addEventListener('auxclick', (e) => { if (e.button === 1) { e.preventDefault(); closeTab(tab); } });
  el.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); activateTab(tab); }
  });

  // Drag a tab left/right to reorder, like a browser
  el.addEventListener('dragstart', (e) => {
    draggingTab = el;
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/x-folio-tab', String(tab.id));
    requestAnimationFrame(() => el.classList.add('dragging'));
  });
  el.addEventListener('dragover', (e) => {
    if (!draggingTab || draggingTab === el) return;
    e.preventDefault();
    const r = el.getBoundingClientRect();
    tabStrip.insertBefore(draggingTab, e.clientX < r.left + r.width / 2 ? el : el.nextSibling);
  });
  el.addEventListener('dragend', () => {
    el.classList.remove('dragging');
    draggingTab = null;
    const order = $$('.tab', tabStrip);
    tabs.sort((a, b) => order.indexOf(a.tabEl) - order.indexOf(b.tabEl));
  });

  tab.tabEl = el;
  tabStrip.appendChild(el);
}
let draggingTab = null;

function activateTab(tab) {
  if (!tab || tab.closed) return;
  // clear the previous tab's search highlights; they're re-applied below for the new tab
  if (active && active !== tab && !findBar.hidden) active.eventBus.dispatch('findbarclose', { source: window });
  active = tab;
  tabs.forEach((t) => {
    const on = t === tab;
    t.container.classList.toggle('active', on);
    t.thumbs.classList.toggle('active', on);
    t.tabEl.classList.toggle('active', on);
    t.tabEl.setAttribute('aria-selected', String(on));
  });
  tab.tabEl.scrollIntoView({ inline: 'nearest', block: 'nearest' });
  syncToolbar();
  refit(tab);
  emit('tabactivated', tab);
  if (!findBar.hidden && findInput.value && tab.pdf) dispatchFind('');
  if (tab.pdf && !isPresenting()) tab.container.focus({ preventScroll: true });
}

function cycleTab(dir) {
  if (tabs.length < 2) return;
  const i = tabs.indexOf(active);
  activateTab(tabs[(i + dir + tabs.length) % tabs.length]);
}

function closeTab(tab) {
  const i = tabs.indexOf(tab);
  if (i < 0) return;
  if (tab.dirty && !confirm(`"${tab.name}" has added text that hasn't been saved.\n\nClose it anyway?`)) return;
  emit('tabclosing', tab);
  tab.closed = true;
  tabs.splice(i, 1);
  tab.thumb.token++;
  tab.thumb.observer?.disconnect();
  try { tab.pdfViewer.setDocument(null); tab.linkService.setDocument(null, null); } catch (_) {}
  tab.tabEl.remove();
  tab.container.remove();
  tab.thumbs.remove();
  if (tab.task) tab.task.destroy().catch(() => {});

  if (tab === active) {
    active = null;
    const next = tabs[i] || tabs[i - 1];
    if (next) activateTab(next); else syncToolbar();
  }
}

/* Re-sync every toolbar control with the active tab */
function syncToolbar() {
  const t = active;
  const hasDoc = !!(t && t.pdf);
  $$('[data-needs-doc]').forEach((el) => (el.disabled = !hasDoc));
  $('#empty').hidden = tabs.length > 0;
  $('#tabbar').hidden = tabs.length === 0;
  $('#loading').hidden = !(t && t.loading);
  document.title = t ? `${t.name} – ${APP_NAME}` : APP_NAME;

  if (!t) {
    pageInput.value = ''; pageTotal.textContent = '/ –';
    findBar.hidden = true; $('#btnSearch').classList.remove('active');
    emit('toolbarsync', t);
    return;
  }
  pageTotal.textContent = t.pdf ? `/ ${t.pdf.numPages}` : '/ –';
  pageInput.value = t.pdf ? t.page : '';
  if (t.lastScale) updateZoomUI(t.lastScale);
  setSegment('scroll', t.view.scrollMode);
  setSegment('spread', t.view.spreadMode);
  setActiveThumb(t, t.page);
  renderFindStatus(t);
  emit('toolbarsync', t);
}

function refit(tab) {
  if (!tab || !tab.pdfViewer.pagesCount) return;
  const v = tab.pdfViewer.currentScaleValue;
  if (['auto', 'page-fit', 'page-width'].includes(v)) tab.pdfViewer.currentScaleValue = v;
  else tab.pdfViewer.update();
}

let resizeTimer = null;
new ResizeObserver(() => {
  clearTimeout(resizeTimer);
  resizeTimer = setTimeout(() => refit(active), 60);
}).observe($('#viewerWrap'));

/* ───────────────────────── Opening files ───────────────────────── */
async function openWithDialog() {
  const files = await window.api.openFileDialog();
  if (files && files.length) await openFiles(files);
}
async function openFiles(files) {
  for (const f of files) await openPdf(f.data, f.name);
}

let pwChain = Promise.resolve();
function askPassword(wasWrong) {
  const p = pwChain.then(() => askPasswordNow(wasWrong));
  pwChain = p.catch(() => {});
  return p;
}
function askPasswordNow(wasWrong) {
  return new Promise((resolve) => {
    const dlg = $('#pwDialog');
    const input = $('#pwInput');
    $('#pwMsg').textContent = wasWrong
      ? 'That password is incorrect. Try again.'
      : 'This document is protected. Enter its password to open it.';
    input.value = '';
    const done = (v) => { dlg.close(); resolve(v); };
    $('#pwForm').onsubmit = (e) => { e.preventDefault(); done(input.value); };
    $('#pwCancel').onclick = () => done(null);
    dlg.oncancel = () => resolve(null);
    dlg.showModal();
    input.focus();
  });
}

async function openPdf(data, name) {
  const tab = createTab(name, data.byteLength);   // size read before PDF.js takes the buffer
  activateTab(tab);
  try {
    const task = pdfjsLib.getDocument({ data, cMapUrl: CMAP_URL, cMapPacked: true, standardFontDataUrl: FONT_URL });
    task.onPassword = async (update, reason) => {
      const pw = await askPassword(reason === pdfjsLib.PasswordResponses.INCORRECT_PASSWORD);
      if (pw === null) { tab.cancelled = true; task.destroy(); } else update(pw);
    };
    tab.task = task;
    const pdf = await task.promise;
    if (tab.closed) { task.destroy(); return; }

    tab.pdf = pdf;
    tab.loading = false;
    tab.pdfViewer.setDocument(pdf);
    tab.linkService.setDocument(pdf, null);
    buildThumbnails(tab);
    if (tab === active) { syncToolbar(); tab.container.focus({ preventScroll: true }); }
  } catch (err) {
    tab.loading = false;
    if (!tab.closed) {
      closeTab(tab);
      if (!tab.cancelled) alert(`Could not open "${name}".\n\n${err && err.message ? err.message : err}`);
    }
  }
}

/* Drag & drop files (ignores tab-reordering drags) */
let dragDepth = 0;
const hasFiles = (e) => [...(e.dataTransfer?.types || [])].includes('Files');
window.addEventListener('dragenter', (e) => { if (!hasFiles(e)) return; e.preventDefault(); dragDepth++; $('#dropHint').hidden = false; });
window.addEventListener('dragleave', (e) => { if (!hasFiles(e)) return; if (--dragDepth <= 0) { dragDepth = 0; $('#dropHint').hidden = true; } });
window.addEventListener('dragover', (e) => { if (hasFiles(e)) e.preventDefault(); });
window.addEventListener('drop', async (e) => {
  if (!hasFiles(e)) return;
  e.preventDefault();
  dragDepth = 0; $('#dropHint').hidden = true;
  const list = [...e.dataTransfer.files].filter((x) => /\.pdf$/i.test(x.name) || x.type === 'application/pdf');
  const files = [];
  for (const f of list) files.push({ name: f.name, data: new Uint8Array(await f.arrayBuffer()) });
  await openFiles(files);
});

$('#btnOpen').addEventListener('click', openWithDialog);
$('#btnOpenEmpty').addEventListener('click', openWithDialog);
$('#btnNewTab').addEventListener('click', openWithDialog);

/* ───────────────────────── Navigation ───────────────────────── */
const goPrev = () => { const v = active?.pdfViewer; if (v && v.currentPageNumber > 1) v.currentPageNumber--; };
const goNext = () => { const v = active?.pdfViewer; if (v && v.currentPageNumber < v.pagesCount) v.currentPageNumber++; };
$('#btnPrev').addEventListener('click', goPrev);
$('#btnNext').addEventListener('click', goNext);

pageInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') pageInput.blur(); });
pageInput.addEventListener('focus', () => pageInput.select());
pageInput.addEventListener('change', () => {
  const v = active?.pdfViewer;
  if (!v) return;
  const n = parseInt(pageInput.value, 10);
  if (Number.isFinite(n)) v.currentPageNumber = Math.min(Math.max(n, 1), v.pagesCount);
  pageInput.value = v.currentPageNumber;
});

/* ───────────────────────── Zoom ───────────────────────── */
function updateZoomUI(e) {
  let value = e.presetValue;
  if (!value) {
    const match = [...zoomSelect.options].find((o) => o.value && !isNaN(o.value) && Math.abs(+o.value - e.scale) < 0.001);
    value = match && match.value;
  }
  if (value && [...zoomSelect.options].some((o) => o.value === value)) {
    zoomSelect.value = value;
  } else {
    const custom = zoomSelect.querySelector('[value="custom"]');
    custom.textContent = `${Math.round(e.scale * 100)}%`;
    custom.hidden = false;
    zoomSelect.value = 'custom';
  }
}

const ZOOM_STEPS = [0.5, 0.75, 1, 1.25, 1.5, 2, 3, 4];
function zoomBy(dir) {
  const v = active?.pdfViewer;
  if (!v || !v.pagesCount) return;
  const s = v.currentScale;
  const next = dir > 0
    ? ZOOM_STEPS.find((z) => z > s + 0.001) ?? ZOOM_STEPS.at(-1)
    : [...ZOOM_STEPS].reverse().find((z) => z < s - 0.001) ?? ZOOM_STEPS[0];
  v.currentScaleValue = String(next);
}
let wheelLock = false;
let slideLock = false;
$('#btnZoomIn').addEventListener('click', () => zoomBy(1));
$('#btnZoomOut').addEventListener('click', () => zoomBy(-1));
zoomSelect.addEventListener('change', () => {
  if (active && zoomSelect.value !== 'custom') active.pdfViewer.currentScaleValue = zoomSelect.value;
  zoomSelect.blur();
});

/* ───────────────────────── Tools: rotate, hand/select, scroll, spread ───────────────────────── */
$('#btnRotate').addEventListener('click', () => {
  if (active) active.pdfViewer.pagesRotation = (active.pdfViewer.pagesRotation + 90) % 360;
});

function setTool(t) {
  tool = t;
  tabs.forEach((x) => {
    x.container.classList.toggle('hand-tool', t === 'hand');
    x.container.classList.toggle('text-tool', t === 'text');
  });
  $('#toolSelect').classList.toggle('active', t === 'select');
  $('#toolHand').classList.toggle('active', t === 'hand');
  $('#toolText').classList.toggle('active', t === 'text');
  emit('toolchanged', t);
}
$('#toolSelect').addEventListener('click', () => setTool('select'));
$('#toolHand').addEventListener('click', () => setTool('hand'));
$('#toolText').addEventListener('click', () => setTool('text'));

let drag = null;
window.addEventListener('mousemove', (e) => {
  if (!drag) return;
  drag.c.scrollLeft = drag.left - (e.clientX - drag.x);
  drag.c.scrollTop = drag.top - (e.clientY - drag.y);
});
window.addEventListener('mouseup', () => { if (drag) drag.c.classList.remove('grabbing'); drag = null; });

function setSegment(attr, value) {
  $$(`[data-${attr}]`).forEach((b) => b.classList.toggle('active', +b.dataset[attr] === value));
}
$$('[data-scroll]').forEach((b) => b.addEventListener('click', () => {
  if (!active) return;
  active.view.scrollMode = +b.dataset.scroll;
  active.pdfViewer.scrollMode = active.view.scrollMode;
  setSegment('scroll', active.view.scrollMode);
}));
$$('[data-spread]').forEach((b) => b.addEventListener('click', () => {
  if (!active) return;
  active.view.spreadMode = +b.dataset.spread;
  active.pdfViewer.spreadMode = active.view.spreadMode;
  setSegment('spread', active.view.spreadMode);
}));

/* ───────────────────────── Sidebar & thumbnails (per tab) ───────────────────────── */
$('#btnSidebar').addEventListener('click', () => {
  const collapsed = sidebar.classList.toggle('collapsed');
  $('#btnSidebar').classList.toggle('active', !collapsed);
});
$('#btnSidebar').classList.add('active');

const THUMB_W = 130;

async function buildThumbnails(tab) {
  const th = tab.thumb;
  const token = ++th.token;
  th.observer?.disconnect();
  th.queue = [];
  tab.thumbs.innerHTML = '';

  const first = await tab.pdf.getPage(1);
  if (token !== th.token) return;
  const vp = first.getViewport({ scale: 1 });
  const height = Math.round((THUMB_W * vp.height) / vp.width);

  const observer = new IntersectionObserver((entries) => {
    for (const en of entries) {
      if (en.isIntersecting) { th.queue.push(en.target); observer.unobserve(en.target); }
    }
    pumpThumbs(tab, token);
  }, { root: tab.thumbs, rootMargin: '500px 0px' });
  th.observer = observer;

  const frag = document.createDocumentFragment();
  for (let n = 1; n <= tab.pdf.numPages; n++) {
    const b = document.createElement('button');
    b.className = 'thumb';
    b.dataset.page = n;
    b.title = `Page ${n}`;
    b.innerHTML = `<span class="thumb-frame" style="width:${THUMB_W}px;height:${height}px"><canvas></canvas></span><span class="thumb-label">${n}</span>`;
    b.addEventListener('click', () => { tab.pdfViewer.currentPageNumber = n; });
    frag.appendChild(b);
  }
  tab.thumbs.appendChild(frag);
  $$('.thumb', tab.thumbs).forEach((el) => observer.observe(el));
  setActiveThumb(tab, tab.page);
}

async function pumpThumbs(tab, token) {
  const th = tab.thumb;
  if (th.busy) return;
  th.busy = true;
  while (th.queue.length && token === th.token) {
    const el = th.queue.shift();
    if (!el.isConnected) continue;
    try {
      const page = await tab.pdf.getPage(+el.dataset.page);
      if (token !== th.token) break;
      const base = page.getViewport({ scale: 1 });
      const scale = THUMB_W / base.width;
      const dpr = window.devicePixelRatio || 1;
      const vp = page.getViewport({ scale: scale * dpr });
      const canvas = $('canvas', el);
      canvas.width = Math.floor(vp.width);
      canvas.height = Math.floor(vp.height);
      canvas.style.width = `${vp.width / dpr}px`;
      canvas.style.height = `${vp.height / dpr}px`;
      $('.thumb-frame', el).style.height = `${vp.height / dpr}px`;
      await page.render({ canvasContext: canvas.getContext('2d'), viewport: vp }).promise;
      el.classList.add('ready');
      page.cleanup();
    } catch (_) { /* thumbnail failures are non-fatal */ }
  }
  th.busy = false;
}

function setActiveThumb(tab, n) {
  $$('.thumb.active', tab.thumbs).forEach((t) => t.classList.remove('active'));
  const el = tab.thumbs.querySelector(`.thumb[data-page="${n}"]`);
  if (!el) return;
  el.classList.add('active');
  if (tab === active) el.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
}

/* ───────────────────────── Find (works on the active tab) ───────────────────────── */
const opts = { highlight: $('#optHighlight'), cs: $('#optCase'), diac: $('#optDiacritics'), whole: $('#optWhole') };
const isOn = (b) => b.getAttribute('aria-pressed') === 'true';

function dispatchFind(type, previous = false) {
  if (!active) return;
  active.eventBus.dispatch('find', {
    source: window, type,
    query: findInput.value,
    caseSensitive: isOn(opts.cs),
    entireWord: isOn(opts.whole),
    highlightAll: isOn(opts.highlight),
    findPrevious: previous,
    matchDiacritics: isOn(opts.diac)
  });
}
function openFind() {
  if (!active || !active.pdf) return;
  findBar.hidden = false;
  $('#btnSearch').classList.add('active');
  findInput.focus();
  findInput.select();
  if (findInput.value) dispatchFind('');
}
function closeFind() {
  findBar.hidden = true;
  $('#btnSearch').classList.remove('active');
  active?.eventBus.dispatch('findbarclose', { source: window });
  findStatus.textContent = '';
  findInput.classList.remove('no-match');
}
function renderFindStatus(tab) {
  const FS = pdfjsViewer.FindState || { FOUND: 0, NOT_FOUND: 1, WRAPPED: 2, PENDING: 3 };
  const { state, counts } = tab.find;
  findInput.classList.toggle('no-match', !!findInput.value && state === FS.NOT_FOUND);
  if (!findInput.value) { findStatus.textContent = ''; return; }
  if (state === FS.NOT_FOUND) { findStatus.textContent = 'Phrase not found'; return; }
  if (state === FS.PENDING && !(counts && counts.total)) { findStatus.textContent = 'Searching…'; return; }
  findStatus.textContent = counts && counts.total > 0
    ? `${counts.current.toLocaleString()} of ${counts.total.toLocaleString()} match${counts.total === 1 ? '' : 'es'}`
    : '';
}

$('#btnSearch').addEventListener('click', () => (findBar.hidden ? openFind() : closeFind()));
$('#findClose').addEventListener('click', closeFind);
$('#findNext').addEventListener('click', () => dispatchFind('again', false));
$('#findPrev').addEventListener('click', () => dispatchFind('again', true));
findInput.addEventListener('input', () => dispatchFind(''));
findInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') { e.preventDefault(); dispatchFind('again', e.shiftKey); }
});
const optTypes = { highlight: 'highlightallchange', cs: 'casesensitivitychange', diac: 'diacriticmatchingchange', whole: 'entirewordchange' };
Object.entries(opts).forEach(([key, btn]) => btn.addEventListener('click', () => {
  btn.setAttribute('aria-pressed', String(!isOn(btn)));
  if (findInput.value) dispatchFind(optTypes[key]);
}));

/* ───────────────────────── Document properties ───────────────────────── */
function formatBytes(b) {
  const kb = b / 1024;
  const human = kb < 1024 ? `${kb.toFixed(kb < 10 ? 1 : 0)} KB` : `${(kb / 1024).toFixed(2)} MB`;
  return `${human} (${b.toLocaleString()} bytes)`;
}
function parsePdfDate(s) {
  const m = /^D:(\d{4})(\d{2})?(\d{2})?(\d{2})?(\d{2})?(\d{2})?(Z|[+-]\d{2}'?(?:\d{2}'?)?)?/.exec(s || '');
  if (!m) return '';
  const [, y, mo = '01', d = '01', h = '00', mi = '00', se = '00', tz] = m;
  let iso = `${y}-${mo}-${d}T${h}:${mi}:${se}`;
  if (tz === 'Z') iso += 'Z';
  else if (tz) { const t = tz.replace(/'/g, ''); iso += `${t.slice(0, 3)}:${t.slice(3, 5) || '00'}`; }
  const dt = new Date(iso);
  return isNaN(dt) ? '' : dt.toLocaleString(undefined, { dateStyle: 'long', timeStyle: 'medium' });
}
function describePageSize(w, h) {
  const mm = [w / 72 * 25.4, h / 72 * 25.4];
  const [a, b] = [Math.min(...mm), Math.max(...mm)];
  const known = { A3: [297, 420], A4: [210, 297], A5: [148, 210], Letter: [215.9, 279.4], Legal: [215.9, 355.6] };
  const name = Object.keys(known).find((k) => Math.abs(known[k][0] - a) < 2.5 && Math.abs(known[k][1] - b) < 2.5);
  const inch = (v) => (v / 72).toFixed(2);
  return `${inch(w)} × ${inch(h)} in (${mm[0].toFixed(0)} × ${mm[1].toFixed(0)} mm${name ? `, ${name}` : ''}, ${w > h ? 'Landscape' : 'Portrait'})`;
}

async function showProperties() {
  const tab = active;
  if (!tab || !tab.pdf) return;
  const { info = {} } = await tab.pdf.getMetadata().catch(() => ({ info: {} }));
  const page = await tab.pdf.getPage(1);
  const vp = page.getViewport({ scale: 1 });
  const v = {
    fileName: tab.name, fileSize: formatBytes(tab.size),
    title: info.Title, author: info.Author, subject: info.Subject, keywords: info.Keywords,
    created: parsePdfDate(info.CreationDate), modified: parsePdfDate(info.ModDate),
    creator: info.Creator, producer: info.Producer, version: info.PDFFormatVersion,
    pages: tab.pdf.numPages,
    pageSize: describePageSize(vp.width, vp.height),
    fastWeb: tab.pdf.isLinearized ? 'Yes' : 'No'
  };
  $$('#propsList [data-p]').forEach((dd) => { dd.textContent = v[dd.dataset.p] || '–'; });
  $('#propsDialog').showModal();
}
$('#btnProps').addEventListener('click', showProperties);
$('#propsClose').addEventListener('click', () => $('#propsDialog').close());
$('#propsDialog').addEventListener('click', (e) => { if (e.target === e.currentTarget) e.currentTarget.close(); });

/* ───────────────────────── Presentation mode ───────────────────────── */
let savedView = null;
$('#btnPresent').addEventListener('click', () => {
  if (active && active.pdf) document.documentElement.requestFullscreen().catch(() => {});
});
document.addEventListener('fullscreenchange', () => {
  const on = !!document.fullscreenElement;
  document.body.classList.toggle('presentation', on);
  if (on && active) {
    const t = active, v = t.pdfViewer;
    savedView = { tab: t, scroll: v.scrollMode, spread: v.spreadMode, scale: v.currentScaleValue };
    v.scrollMode = 3;           // one page at a time
    v.spreadMode = 0;
    setTimeout(() => { if (!t.closed) v.currentScaleValue = 'page-fit'; }, 150);
  } else if (!on && savedView) {
    const s = savedView; savedView = null;
    if (s.tab.closed) return;
    s.tab.pdfViewer.scrollMode = s.scroll;
    s.tab.pdfViewer.spreadMode = s.spread;
    setTimeout(() => { if (!s.tab.closed) s.tab.pdfViewer.currentScaleValue = s.scale; }, 150);
  }
});

/* ───────────────────────── Keyboard shortcuts ───────────────────────── */
window.addEventListener('keydown', (e) => {
  const mod = e.ctrlKey || e.metaKey;
  const k = e.key;

  if (mod && k.toLowerCase() === 'o') { e.preventDefault(); openWithDialog(); return; }
  if (mod && k.toLowerCase() === 'f') { e.preventDefault(); openFind(); return; }
  if (mod && (k === '=' || k === '+')) { e.preventDefault(); zoomBy(1); return; }
  if (mod && (k === '-' || k === '_')) { e.preventDefault(); zoomBy(-1); return; }
  if (mod && k === '0') { e.preventDefault(); if (active?.pdf) active.pdfViewer.currentScaleValue = 'auto'; return; }

  // Tab shortcuts (same as Chrome)
  if (!isPresenting()) {
    if (mod && k.toLowerCase() === 'w') { e.preventDefault(); if (active) closeTab(active); return; }
    if (mod && k === 'Tab') { e.preventDefault(); cycleTab(e.shiftKey ? -1 : 1); return; }
    if (mod && k === 'PageDown') { e.preventDefault(); cycleTab(1); return; }
    if (mod && k === 'PageUp') { e.preventDefault(); cycleTab(-1); return; }
    if (mod && /^[1-9]$/.test(k)) {
      e.preventDefault();
      const t = k === '9' ? tabs[tabs.length - 1] : tabs[+k - 1];
      if (t) activateTab(t);
      return;
    }
  }

  if (k === 'Escape' && !findBar.hidden) { closeFind(); return; }

  const tag = document.activeElement?.tagName;
  if (tag === 'INPUT' || tag === 'SELECT' || tag === 'TEXTAREA' || document.activeElement?.isContentEditable || !active?.pdf) return;
  const v = active.pdfViewer;

  if (isPresenting()) {
    if (['ArrowRight', 'ArrowDown', 'PageDown', ' ', 'Enter'].includes(k)) { e.preventDefault(); goNext(); }
    else if (['ArrowLeft', 'ArrowUp', 'PageUp', 'Backspace'].includes(k)) { e.preventDefault(); goPrev(); }
    else if (k === 'Home') v.currentPageNumber = 1;
    else if (k === 'End') v.currentPageNumber = v.pagesCount;
    return;
  }
  if (k === 'n' || k === 'j') goNext();
  else if (k === 'p' || k === 'k') goPrev();
  else if (k === 'Home' && !mod) v.currentPageNumber = 1;
  else if (k === 'End' && !mod) v.currentPageNumber = v.pagesCount;
});

/* ───────────────────────── Startup ───────────────────────── */
syncToolbar();
window.api.getInitialFile().then((files) => { if (files && files.length) openFiles(files); });
