'use strict';
/* Add-text tool: click a page, type, style it, then "Save" a copy of the PDF
   with the text written into it (using the real installed font files). */
(function () {
  const F = window.Folio;
  const { $, $$ } = F;
  const LINE = 1.2;                         // line height (× font size), identical on screen, canvas and PDF
  const defaults = { family: 'Arial', size: 16, color: '#000000', bold: false, italic: false, underline: false };
  let uid = 0;
  let lastTab = null;

  const bar = $('#textBar');
  const fontSel = $('#fontSelect');
  const sizeIn = $('#fontSize');
  const colorIn = $('#fontColor');
  const btnB = $('#fmtBold'), btnI = $('#fmtItalic'), btnU = $('#fmtUnder'), btnDel = $('#fmtDelete');

  /* ───────── helpers ───────── */
  const findAnnot = (tab, id) => tab.annots.find((a) => a.id === id);
  const pageView = (tab, n) => tab.pdfViewer.getPageView(n - 1);
  const readText = (el) => el.innerText.replace(/\r/g, '').replace(/\n$/, '');

  function snapshot(tab) {
    return JSON.stringify(tab.annots.filter((a) => a.text.trim())
      .map((a) => [a.page, a.x, a.y, a.text, a.family, a.size, a.color, a.bold, a.italic, a.underline]));
  }
  function updateSaveBtn() {
    const t = F.active;
    $('#btnSave').disabled = !(t && t.pdf && t.annots.some((a) => a.text.trim()));
  }
  function markChanged(tab) {
    tab.dirty = snapshot(tab) !== tab.saved;
    tab.tabEl.classList.toggle('dirty', tab.dirty);
    updateSaveBtn();
  }

  /* ───────── font list ───────── */
  const FALLBACK_FONTS = ['Arial', 'Calibri', 'Cambria', 'Comic Sans MS', 'Consolas', 'Courier New', 'Georgia', 'Impact',
    'Segoe UI', 'Tahoma', 'Times New Roman', 'Trebuchet MS', 'Verdana'];
  function populateFonts(list) {
    const current = defaults.family;
    fontSel.innerHTML = '';
    for (const name of list) {
      const o = document.createElement('option');
      o.value = name; o.textContent = name;
      o.style.fontFamily = `"${name}", sans-serif`;
      fontSel.appendChild(o);
    }
    if (![...fontSel.options].some((o) => o.value === current)) {
      const o = document.createElement('option'); o.value = current; o.textContent = current; fontSel.prepend(o);
    }
    fontSel.value = current;
  }
  populateFonts(FALLBACK_FONTS);
  window.api.listFonts().then((list) => { if (list && list.length) populateFonts(list); }).catch(() => {});

  /* ───────── annotation elements ───────── */
  function styleEl(tab, a) {
    const pv = pageView(tab, a.page);
    if (!pv || !pv.viewport) return;
    const vp = pv.viewport;
    const [vx, vy] = vp.convertToViewportPoint(a.x, a.y);
    a.el.style.left = `${vx}px`;
    a.el.style.top = `${vy}px`;
    a.el.style.transform = vp.rotation ? `rotate(${vp.rotation}deg)` : '';
    const t = a.textEl.style;
    t.fontFamily = `"${a.family}", sans-serif`;
    t.fontSize = `${a.size * vp.scale}px`;
    t.color = a.color;
    t.fontWeight = a.bold ? '700' : '400';
    t.fontStyle = a.italic ? 'italic' : 'normal';
    t.textDecoration = a.underline ? 'underline' : 'none';
  }

  function mount(tab, a) {
    const pv = pageView(tab, a.page);
    if (!pv || !pv.div) return;
    let layer = pv.div.querySelector(':scope > .ta-layer');
    if (!layer) {
      layer = document.createElement('div');
      layer.className = 'ta-layer';
      pv.div.appendChild(layer);
    }
    if (a.el.parentNode !== layer) layer.appendChild(a.el);
    styleEl(tab, a);
  }

  function focusAnnot(a) {
    a.textEl.focus();
    const sel = window.getSelection();
    const r = document.createRange();
    r.selectNodeContents(a.textEl);
    r.collapse(false);
    sel.removeAllRanges();
    sel.addRange(r);
  }

  function removeAnnot(tab, id) {
    const a = findAnnot(tab, id);
    if (!a) return;
    a.el.remove();
    tab.annots = tab.annots.filter((x) => x.id !== id);
    if (tab.selectedId === id) tab.selectedId = null;
    markChanged(tab);
    syncBar();
  }

  function pruneEmpty(tab, exceptId) {
    if (!tab) return;
    tab.annots.filter((a) => !a.text.trim() && a.id !== exceptId).forEach((a) => removeAnnot(tab, a.id));
  }

  function select(tab, id) {
    if (tab.selectedId === id) { syncBar(); return; }
    tab.selectedId = id;
    tab.annots.forEach((a) => a.el.classList.toggle('selected', a.id === id));
    pruneEmpty(tab, id);
    syncBar();
  }

  function toggleFmt(key) {
    applyFormat({ [key]: !currentSource()[key] });
  }

  function buildEl(tab, a) {
    const el = document.createElement('div');
    el.className = 'ta';
    const grip = document.createElement('div');
    grip.className = 'ta-grip';
    grip.title = 'Drag to move';
    const t = document.createElement('div');
    t.className = 'ta-text';
    t.contentEditable = 'plaintext-only';
    t.spellcheck = false;
    t.textContent = a.text;
    el.append(grip, t);
    a.el = el; a.textEl = t;

    t.addEventListener('mousedown', () => select(tab, a.id));
    t.addEventListener('focus', () => select(tab, a.id));
    t.addEventListener('input', () => { a.text = readText(t); markChanged(tab); });
    t.addEventListener('blur', () => setTimeout(() => {
      const ae = document.activeElement;
      if (ae === t || (ae && ae.closest && ae.closest('#textBar'))) return;
      if (!a.text.trim() && tab.annots.includes(a)) removeAnnot(tab, a.id);
    }, 0));
    t.addEventListener('keydown', (e) => {
      const mod = e.ctrlKey || e.metaKey;
      if (mod && e.key.toLowerCase() === 'b') { e.preventDefault(); toggleFmt('bold'); }
      else if (mod && e.key.toLowerCase() === 'i') { e.preventDefault(); toggleFmt('italic'); }
      else if (mod && e.key.toLowerCase() === 'u') { e.preventDefault(); toggleFmt('underline'); }
      else if (e.key === 'Escape') { e.preventDefault(); t.blur(); }
    });

    // drag the handle to move the text box
    grip.addEventListener('mousedown', (e) => {
      e.preventDefault(); e.stopPropagation();
      select(tab, a.id);
      const pv = pageView(tab, a.page);
      const vp = pv.viewport;
      const [sx, sy] = vp.convertToViewportPoint(a.x, a.y);
      const x0 = e.clientX, y0 = e.clientY;
      const move = (ev) => { el.style.left = `${sx + ev.clientX - x0}px`; el.style.top = `${sy + ev.clientY - y0}px`; };
      const up = (ev) => {
        window.removeEventListener('mousemove', move);
        window.removeEventListener('mouseup', up);
        const [nx, ny] = vp.convertToPdfPoint(sx + ev.clientX - x0, sy + ev.clientY - y0);
        a.x = nx; a.y = ny;
        styleEl(tab, a);
        markChanged(tab);
      };
      window.addEventListener('mousemove', move);
      window.addEventListener('mouseup', up);
    });
  }

  function createAnnot(tab, page, x, y) {
    const a = { id: ++uid, page, x, y, text: '', ...defaults };
    buildEl(tab, a);
    tab.annots.push(a);
    mount(tab, a);
    select(tab, a.id);
    focusAnnot(a);
  }

  /* ───────── format bar ───────── */
  const currentSource = () => {
    const tab = F.active;
    return (tab && findAnnot(tab, tab.selectedId)) || defaults;
  };

  function syncBar() {
    const src = currentSource();
    if (![...fontSel.options].some((o) => o.value === src.family)) {
      const o = document.createElement('option'); o.value = src.family; o.textContent = src.family; fontSel.prepend(o);
    }
    fontSel.value = src.family;
    if (document.activeElement !== sizeIn) sizeIn.value = src.size;
    colorIn.value = src.color;
    btnB.classList.toggle('active', !!src.bold);
    btnI.classList.toggle('active', !!src.italic);
    btnU.classList.toggle('active', !!src.underline);
    const tab = F.active;
    btnDel.disabled = !(tab && findAnnot(tab, tab.selectedId));
  }

  function applyFormat(patch) {
    const tab = F.active;
    if (!tab) return;
    Object.assign(defaults, patch);
    const sel = findAnnot(tab, tab.selectedId);
    if (sel) { Object.assign(sel, patch); styleEl(tab, sel); markChanged(tab); }
    syncBar();
  }
  const refocus = () => {
    const tab = F.active;
    const sel = tab && findAnnot(tab, tab.selectedId);
    if (sel) focusAnnot(sel);
  };

  fontSel.addEventListener('change', () => { applyFormat({ family: fontSel.value }); refocus(); });
  sizeIn.addEventListener('input', () => {
    const v = parseFloat(sizeIn.value);
    if (Number.isFinite(v) && v >= 1 && v <= 400) applyFormat({ size: v });
  });
  colorIn.addEventListener('input', () => applyFormat({ color: colorIn.value }));
  colorIn.addEventListener('change', refocus);
  [[btnB, 'bold'], [btnI, 'italic'], [btnU, 'underline']].forEach(([btn, key]) => {
    btn.addEventListener('mousedown', (e) => e.preventDefault());   // keep the caret in the text box
    btn.addEventListener('click', () => toggleFmt(key));
  });
  btnDel.addEventListener('mousedown', (e) => e.preventDefault());
  btnDel.addEventListener('click', () => {
    const tab = F.active;
    if (tab && tab.selectedId) removeAnnot(tab, tab.selectedId);
  });

  function updateBarVisibility() {
    const on = F.tool === 'text' && F.active && F.active.pdf;
    bar.hidden = !on;
    $('#app').classList.toggle('has-textbar', !!on);
  }

  /* ───────── per-tab wiring ───────── */
  F.on('tabcreated', (tab) => {
    tab.container.addEventListener('mousedown', (e) => {
      if (F.tool !== 'text' || e.button !== 0 || e.target.closest('.ta')) return;
      const pageDiv = e.target.closest('.page');
      if (!pageDiv) { select(tab, null); return; }
      e.preventDefault();                       // don't start a text selection in the PDF
      const n = +pageDiv.dataset.pageNumber;
      const pv = pageView(tab, n);
      if (!pv || !pv.viewport) return;
      const vp = pv.viewport;
      if (vp.rotation !== 0) { F.toast('Rotate the page back to 0° to add new text.'); return; }
      const rect = pageDiv.getBoundingClientRect();
      const px = e.clientX - rect.left, py = e.clientY - rect.top;
      const lineH = defaults.size * vp.scale * LINE;
      const [x, y] = vp.convertToPdfPoint(px, py - lineH / 2);    // centre the first line on the click
      createAnnot(tab, n, x, y);
    });
  });
  F.on('pagerendered', (tab, n) => tab.annots.filter((a) => a.page === n).forEach((a) => mount(tab, a)));
  F.on('viewchanged', (tab) => tab.annots.forEach((a) => mount(tab, a)));
  F.on('tabactivated', (tab) => {
    if (lastTab && lastTab !== tab) pruneEmpty(lastTab);
    lastTab = tab;
    syncBar(); updateBarVisibility(); updateSaveBtn();
  });
  F.on('tabclosing', (tab) => { if (lastTab === tab) lastTab = null; });
  F.on('toolbarsync', () => { updateBarVisibility(); updateSaveBtn(); });
  F.on('toolchanged', (t) => {
    if (t !== 'text') {
      const ae = document.activeElement;
      if (ae && ae.isContentEditable) ae.blur();
      pruneEmpty(F.active);
    }
    updateBarVisibility(); syncBar();
  });

  /* ───────── drawing onto canvases (used by Print) ───────── */
  F.drawMarkups = function (tab, pageNum, ctx, vp) {
    for (const a of tab.annots) {
      if (a.page !== pageNum || !a.text.trim()) continue;
      ctx.save();
      const [vx, vy] = vp.convertToViewportPoint(a.x, a.y);
      ctx.translate(vx, vy);
      if (vp.rotation) ctx.rotate((vp.rotation * Math.PI) / 180);
      const px = a.size * vp.scale;
      ctx.font = `${a.italic ? 'italic ' : ''}${a.bold ? '700 ' : ''}${px}px "${a.family}", sans-serif`;
      ctx.fillStyle = a.color;
      ctx.textBaseline = 'alphabetic';
      const m = ctx.measureText('Hg');
      const fa = m.fontBoundingBoxAscent != null ? m.fontBoundingBoxAscent : px * 0.905;
      const fd = m.fontBoundingBoxDescent != null ? m.fontBoundingBoxDescent : px * 0.212;
      const lh = px * LINE;
      const base = (lh - (fa + fd)) / 2 + fa;
      a.text.split('\n').forEach((line, i) => {
        const y = base + i * lh;
        ctx.fillText(line, 0, y);
        if (a.underline && line) ctx.fillRect(0, y + px * 0.1, ctx.measureText(line).width, Math.max(1, px * 0.06));
      });
      ctx.restore();
    }
  };

  /* ───────── Save a copy ───────── */
  async function saveCopy() {
    const tab = F.active;
    if (!tab || !tab.pdf) return;
    pruneEmpty(tab);
    const annots = tab.annots.filter((a) => a.text.trim()).map((a) => ({
      page: a.page, x: a.x, y: a.y, text: a.text, family: a.family, size: a.size,
      color: a.color, bold: a.bold, italic: a.italic, underline: a.underline
    }));
    if (!annots.length) { F.toast('There is no added text to save yet.'); return; }
    F.busy(true);
    try {
      const bytes = await tab.pdf.getData();
      const res = await window.api.saveAnnotatedPdf({
        bytes, annots, suggestedName: tab.name.replace(/\.pdf$/i, '') + ' - edited.pdf'
      });
      if (res.canceled) return;
      if (res.error) {
        const hint = /Cannot find module/i.test(res.error) ? '\n\nRun this in the app folder, then restart:\nnpm install pdf-lib @pdf-lib/fontkit'
          : /encrypt/i.test(res.error) ? '\n\nThis PDF is password-protected, which can\'t be edited.' : '';
        alert(`Could not save the PDF.\n\n${res.error}${hint}`);
        return;
      }
      tab.saved = snapshot(tab);
      markChanged(tab);
      F.toast(`Saved: ${res.path}`);
    } catch (err) {
      alert(`Could not save the PDF.\n\n${err && err.message ? err.message : err}`);
    } finally {
      F.busy(false);
    }
  }
  $('#btnSave').addEventListener('click', saveCopy);

  /* ───────── keyboard ───────── */
  window.addEventListener('keydown', (e) => {
    const mod = e.ctrlKey || e.metaKey;
    if (mod && e.key.toLowerCase() === 's') { e.preventDefault(); saveCopy(); return; }
    const tab = F.active;
    if (F.tool !== 'text' || !tab || !tab.selectedId) return;
    const a = findAnnot(tab, tab.selectedId);
    if (a && e.key === 'Delete' && (!a.text.trim() || document.activeElement !== a.textEl)) {
      e.preventDefault();
      removeAnnot(tab, a.id);
    }
  });

  syncBar();
})();
