'use strict';
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('api', {
  openFileDialog: () => ipcRenderer.invoke('dialog:open'),
  getInitialFile: () => ipcRenderer.invoke('app:initial-file'),
  listFonts: () => ipcRenderer.invoke('fonts:list'),
  saveAnnotatedPdf: (payload) => ipcRenderer.invoke('pdf:save-annotated', payload),
  getPrinters: () => ipcRenderer.invoke('print:printers'),
  printHtml: (job) => ipcRenderer.invoke('print:run', job)
});
