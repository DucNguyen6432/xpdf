'use strict';
const { app, BrowserWindow, ipcMain, dialog, Menu } = require('electron');
const fs = require('fs');
const path = require('path');
const os = require('os');

const APP_NAME = 'x PDF Reader';
let win = null;

/* ───────────── Opening files ───────────── */
function findInitialPdfs() {
  const args = process.argv.slice(app.isPackaged ? 1 : 2);
  return args.filter((a) => a.toLowerCase().endsWith('.pdf') && fs.existsSync(a));
}

async function readPdf(filePath) {
  const buf = await fs.promises.readFile(filePath);
  return { name: path.basename(filePath), size: buf.length, data: new Uint8Array(buf) };
}

function createWindow() {
  win = new BrowserWindow({
    width: 1320,
    height: 880,
    minWidth: 1100,
    minHeight: 600,
    backgroundColor: '#18181b',
    title: APP_NAME,
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false
    }
  });
  win.loadFile(path.join(__dirname, 'src', 'index.html'));
  // F12 toggles developer tools (handy if something misbehaves)
  win.webContents.on('before-input-event', (_e, input) => {
    if (input.type === 'keyDown' && input.key === 'F12') win.webContents.toggleDevTools();
  });
  win.on('closed', () => (win = null));
}

ipcMain.handle('dialog:open', async () => {
  const res = await dialog.showOpenDialog(win, {
    title: 'Open PDF',
    properties: ['openFile', 'multiSelections'],
    filters: [{ name: 'PDF documents', extensions: ['pdf'] }]
  });
  if (res.canceled || !res.filePaths.length) return [];
  return Promise.all(res.filePaths.map(readPdf));
});

ipcMain.handle('app:initial-file', async () => Promise.all(findInitialPdfs().map(readPdf)));

/* ───────────── Installed fonts ─────────────
   We scan the system font folders once (cached on disk) so the text tool can
   offer every installed font and embed the real font file when saving. */
function loadFontkit() {
  const fk = require('@pdf-lib/fontkit');
  return fk.default || fk;
}

function fontDirs() {
  const home = os.homedir();
  if (process.platform === 'win32') {
    return [path.join(process.env.WINDIR || 'C:\\Windows', 'Fonts'),
            path.join(process.env.LOCALAPPDATA || path.join(home, 'AppData', 'Local'), 'Microsoft', 'Windows', 'Fonts')];
  }
  if (process.platform === 'darwin') {
    return ['/System/Library/Fonts', '/Library/Fonts', path.join(home, 'Library', 'Fonts')];
  }
  return ['/usr/share/fonts', '/usr/local/share/fonts', path.join(home, '.fonts'), path.join(home, '.local', 'share', 'fonts')];
}

async function walk(dir, out, depth = 0) {
  let entries;
  try { entries = await fs.promises.readdir(dir, { withFileTypes: true }); } catch (_) { return; }
  for (const e of entries) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) { if (depth < 4) await walk(p, out, depth + 1); }
    else if (/\.(ttf|otf)$/i.test(e.name)) out.push(p);   // .ttc collections are skipped
  }
}

let fontFaces = [];            // [{ family, bold, italic, path }]
let fontIndexPromise = null;

function ensureFontIndex() {
  if (!fontIndexPromise) fontIndexPromise = buildFontIndex().catch((e) => { console.error('font scan failed', e); fontFaces = []; });
  return fontIndexPromise;
}

async function buildFontIndex() {
  const fontkit = loadFontkit();
  const files = [];
  for (const d of fontDirs()) await walk(d, files);

  const cachePath = path.join(app.getPath('userData'), 'font-index.json');
  let cache = {};
  try { cache = JSON.parse(await fs.promises.readFile(cachePath, 'utf8')); } catch (_) {}
  const next = {};
  const faces = [];
  let n = 0;

  for (const f of files) {
    let st;
    try { st = await fs.promises.stat(f); } catch (_) { continue; }
    let entry = cache[f];
    if (!entry || entry.m !== st.mtimeMs || entry.s !== st.size) {
      let face = null;
      if (st.size < 40 * 1024 * 1024) {
        try {
          const font = fontkit.create(await fs.promises.readFile(f));
          if (font && !font.fonts && font.familyName) {
            const sub = font.subfamilyName || '';
            face = { family: font.familyName, bold: /(^|\s)bold(\s|$)/i.test(sub), italic: /italic|oblique/i.test(sub) };
          }
        } catch (_) { /* unreadable font: skip */ }
      }
      entry = { m: st.mtimeMs, s: st.size, face };
    }
    next[f] = entry;
    if (entry.face) faces.push({ ...entry.face, path: f });
    if (++n % 20 === 0) await new Promise((r) => setImmediate(r));   // keep the app responsive
  }
  fontFaces = faces;
  try { await fs.promises.writeFile(cachePath, JSON.stringify(next)); } catch (_) {}
}

function findFace(family, bold, italic) {
  const want = String(family || '').toLowerCase();
  let best = null, bestScore = Infinity;
  for (const f of fontFaces) {
    if (f.family.toLowerCase() !== want) continue;
    const score = (f.bold === !!bold ? 0 : 2) + (f.italic === !!italic ? 0 : 1);
    if (score < bestScore) { best = f; bestScore = score; }
  }
  return best;
}

ipcMain.handle('fonts:list', async () => {
  await ensureFontIndex();
  const set = new Set(fontFaces.map((f) => f.family).filter((n) => n && !n.startsWith('@')));
  return [...set].sort((a, b) => a.localeCompare(b));
});

/* ───────────── Saving added text into a PDF ───────────── */
function hexToRgb(hex, rgb) {
  const m = /^#?([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i.exec(hex || '');
  return m ? rgb(parseInt(m[1], 16) / 255, parseInt(m[2], 16) / 255, parseInt(m[3], 16) / 255) : rgb(0, 0, 0);
}

async function exportWithText(bytes, annots) {
  const { PDFDocument, StandardFonts, rgb } = require('pdf-lib');
  const fontkit = loadFontkit();
  const doc = await PDFDocument.load(bytes);
  doc.registerFontkit(fontkit);
  await ensureFontIndex();

  const cache = new Map();
  async function getFont(a) {
    const key = `${a.family}|${a.bold}|${a.italic}`;
    if (cache.has(key)) return cache.get(key);
    let entry = null;
    const face = findFace(a.family, a.bold, a.italic);
    if (face) {
      try {
        const fb = await fs.promises.readFile(face.path);
        let font;
        try { font = await doc.embedFont(fb, { subset: true }); } catch (_) { font = await doc.embedFont(fb); }
        const fk = fontkit.create(fb);
        entry = { font, asc: fk.ascent / fk.unitsPerEm, desc: -fk.descent / fk.unitsPerEm, unicode: true };
      } catch (_) { entry = null; }
    }
    if (!entry) {   // font not found / not embeddable: fall back to Helvetica
      const std = a.bold && a.italic ? StandardFonts.HelveticaBoldOblique
        : a.bold ? StandardFonts.HelveticaBold
        : a.italic ? StandardFonts.HelveticaOblique : StandardFonts.Helvetica;
      entry = { font: await doc.embedFont(std), asc: 0.905, desc: 0.212, unicode: false };
    }
    cache.set(key, entry);
    return entry;
  }

  const pages = doc.getPages();
  for (const a of annots) {
    const page = pages[a.page - 1];
    if (!page) continue;
    const f = await getFont(a);
    const color = hexToRgb(a.color, rgb);
    const lineH = a.size * 1.2;
    const firstBase = (lineH - (f.asc + f.desc) * a.size) / 2 + f.asc * a.size;   // same maths as the on-screen box
    const lines = String(a.text).replace(/\r/g, '').split('\n');
    for (let i = 0; i < lines.length; i++) {
      let line = lines[i];
      if (!line) continue;
      const y = a.y - firstBase - i * lineH;
      const clean = (t) => t.replace(/[^\x20-\x7E\xA0-\xFF]/g, '?');
      if (!f.unicode) line = clean(line);
      try { page.drawText(line, { x: a.x, y, size: a.size, font: f.font, color }); }
      catch (_) { line = clean(line); page.drawText(line, { x: a.x, y, size: a.size, font: f.font, color }); }
      if (a.underline) {
        const w = f.font.widthOfTextAtSize(line, a.size);
        const uy = y - a.size * 0.1;
        page.drawLine({ start: { x: a.x, y: uy }, end: { x: a.x + w, y: uy }, thickness: Math.max(0.5, a.size * 0.06), color });
      }
    }
  }
  return Buffer.from(await doc.save());
}

ipcMain.handle('pdf:save-annotated', async (_e, { bytes, annots, suggestedName }) => {
  const res = await dialog.showSaveDialog(win, {
    title: 'Save PDF with added text',
    defaultPath: suggestedName,
    filters: [{ name: 'PDF documents', extensions: ['pdf'] }]
  });
  if (res.canceled || !res.filePath) return { canceled: true };
  try {
    const out = await exportWithText(bytes, annots);
    await fs.promises.writeFile(res.filePath, out);
    return { path: res.filePath };
  } catch (e) {
    return { error: String((e && e.message) || e) };
  }
});

/* ───────────── Printing ───────────── */
ipcMain.handle('print:printers', async () => {
  try {
    const list = await win.webContents.getPrintersAsync();
    return list.map((p) => ({ name: p.name, displayName: p.displayName || p.name, isDefault: !!p.isDefault }));
  } catch (_) { return []; }
});

ipcMain.handle('print:run', async (_e, job) => {
  const tmp = path.join(app.getPath('temp'), `xpdf-print-${Date.now()}.html`);
  let w = null;
  try {
    await fs.promises.writeFile(tmp, job.html, 'utf8');
    w = new BrowserWindow({ show: false, webPreferences: { sandbox: true, contextIsolation: true } });
    await w.loadFile(tmp);
    // make sure every page image is decoded before printing
    await w.webContents.executeJavaScript(`Promise.all([...document.querySelectorAll('.pg')].map((el) => {
      const m = /url\\("?([^")]+)"?\\)/.exec(getComputedStyle(el).backgroundImage);
      if (!m) return null;
      const i = new Image(); i.src = m[1]; return i.decode().catch(() => {});
    })).then(() => true)`);
    await new Promise((r) => setTimeout(r, 300));
    return await new Promise((resolve) => {
      w.webContents.print({
        silent: true,
        printBackground: true,
        deviceName: job.deviceName,
        color: job.color,
        copies: job.copies,
        collate: job.collate,
        duplexMode: job.duplexMode,
        landscape: job.landscape,
        pageSize: job.pageSize,
        margins: { marginType: 'none' }
      }, (success, reason) => resolve({ success, reason }));
    });
  } catch (e) {
    return { success: false, reason: String((e && e.message) || e) };
  } finally {
    if (w) w.destroy();
    fs.promises.unlink(tmp).catch(() => {});
  }
});

app.whenReady().then(() => {
  Menu.setApplicationMenu(null);
  createWindow();
  setTimeout(() => ensureFontIndex(), 1500);   // warm up the font list in the background
  app.on('activate', () => BrowserWindow.getAllWindows().length === 0 && createWindow());
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
